# @input-output-hk/lace-sdk

Headless SDK for the Lace wallet platform. Create and manage Cardano wallets with passkeys or other key sources, reactive state observables, and a modular architecture.

## Installation

The package is published to [GitHub Packages](https://github.com/input-output-hk/lace-platform/packages). You need to configure npm to use the GitHub registry for the `@input-output-hk` scope.

### 1. Authenticate with GitHub Packages

Create a [personal access token](https://github.com/settings/tokens) (classic) with `read:packages` scope, then log in:

```bash
npm login --scope=@input-output-hk --registry=https://npm.pkg.github.com
```

Or add it directly to your project's `.npmrc`:

```ini
# .npmrc
@input-output-hk:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=YOUR_GITHUB_TOKEN
```

### 2. Install

```bash
npm install @input-output-hk/lace-sdk
```

> **Note:** Published versions use the `dev` dist-tag (e.g., `0.1.0-dev.42`). To install the latest dev release:
>
> ```bash
> npm install @input-output-hk/lace-sdk@dev
> ```

## Quick Start

```typescript
import {
  createLaceWallet,
  FEATURE_FLAG_CARDANO,
  FEATURE_FLAG_NETWORK_TYPE,
  m,
} from '@input-output-hk/lace-sdk/cardano';

const wallet = await createLaceWallet({
  modules: [
    m.featureDev,
    m.storageInMemory,
    m.blockchainCardano,
    m.cardanoProviderBlockfrost,
    m.cryptoCardanoSdk,
  ] as const,
  environment: 'development',
  featureFlags: [
    { key: FEATURE_FLAG_CARDANO },
    { key: FEATURE_FLAG_NETWORK_TYPE, payload: 'testnet' },
  ],
  config: {
    /* see Configuration */
  },
});

// Subscribe to reactive state
wallet.stateObservables.addresses.selectAllAddresses$.subscribe(addresses => {
  console.log('Addresses:', addresses);
});

wallet.stateObservables.tokens.selectAllTokens$.subscribe(tokens => {
  console.log('Tokens:', tokens);
});

// Read state synchronously
const state = wallet.getState();
```

## Configuration

The SDK requires an `AppConfig` object with Blockfrost provider credentials and network settings.

```typescript
import {
  Cardano,
  FEATURE_FLAG_CARDANO,
  FEATURE_FLAG_NETWORK_TYPE,
  Milliseconds,
  type AppConfig,
} from '@input-output-hk/lace-sdk/cardano';

const featureFlags = [
  { key: FEATURE_FLAG_CARDANO },
  { key: FEATURE_FLAG_NETWORK_TYPE, payload: 'testnet' },
];

const config: Partial<AppConfig> = {
  defaultFeatureFlags: featureFlags,
  extraFeatureFlags: [],
  defaultTestnetChainId: Cardano.ChainIds.Preprod,
  cardanoProvider: {
    tipPollFrequency: Milliseconds(30_000),
    blockfrostConfigs: {
      // Keyed by Cardano network magic
      1: {
        clientConfig: {
          baseUrl: 'https://cardano-preprod.blockfrost.io',
          apiVersion: 'v0',
          projectId: 'YOUR_PREPROD_PROJECT_ID',
        },
        rateLimiterConfig: {
          size: 500,
          increaseAmount: 10,
          increaseInterval: Milliseconds(1000),
        },
      },
      2: {
        clientConfig: {
          baseUrl: 'https://cardano-preview.blockfrost.io',
          apiVersion: 'v0',
          projectId: 'YOUR_PREVIEW_PROJECT_ID',
        },
        rateLimiterConfig: {
          size: 500,
          increaseAmount: 10,
          increaseInterval: Milliseconds(1000),
        },
      },
      764824073: {
        clientConfig: {
          baseUrl: 'https://cardano-mainnet.blockfrost.io',
          apiVersion: 'v0',
          projectId: 'YOUR_MAINNET_PROJECT_ID',
        },
        rateLimiterConfig: {
          size: 500,
          increaseAmount: 10,
          increaseInterval: Milliseconds(1000),
        },
      },
    },
  },
  cexplorerUrls: {
    1: 'https://preprod.cexplorer.io',
    2: 'https://preview.cexplorer.io',
    764824073: 'https://cexplorer.io',
  },
};
```

## Modules

The SDK uses a modular architecture. Pre-configured modules are available via the `m` namespace export:

### Feature Flags — `featureDev`

Static, in-memory feature flag evaluation. Feature flags are set at initialization time and remain fixed for the lifetime of the wallet. Suitable for development, testing, and applications where flags are known at build time.

**Platform alternative (not yet in SDK):** `feature-posthog` — evaluates flags dynamically via [PostHog](https://posthog.com/), allowing remote flag updates without redeploying.

### Storage — `storageInMemory`

Ephemeral in-memory key-value storage. State is lost when the process exits. Useful for serverless, testing, or short-lived sessions where persistence is not needed.

**Platform alternatives (not yet in SDK):**

- `storage-extension` — persists to `chrome.storage.local` (browser extensions)
- `storage-react-native-async` — persists to React Native AsyncStorage (mobile)

### Blockchain — `blockchainCardano`

Full Cardano blockchain integration: address discovery, UTXO management, token tracking, transaction building, delegation, and in-memory wallet signing.

When Cardano feature is active, the SDK also loads the headless Cardano sync executor. Adding a verified wallet starts address discovery; UTXO sync follows discovered addresses. `requestManualAddressDiscovery` then has a handler for thorough rescans.

**Platform alternatives (not yet in SDK):**

- `blockchain-bitcoin` — Bitcoin UTXO model, address validation, fee estimation
- `blockchain-midnight` — Midnight privacy blockchain with shielded contracts

Multiple blockchain modules can be loaded simultaneously — the wallet manages accounts across all active chains.

### Provider — `cardanoProviderBlockfrost`

Fetches on-chain Cardano data (UTXOs, transactions, stake info, network parameters) via the [Blockfrost](https://blockfrost.io/) API. Requires a Blockfrost project ID per network.

### Cryptography — `cryptoCardanoSdk`

Provides `bip32Ed25519` key derivation and `blake2b` hashing using the `@cardano-sdk` library.

**Platform alternative (not yet in SDK):** `crypto-apollo` — same cryptographic interface backed by the Apollo library.

### Passport (`createPassportAccountModule`)

Passkey-backed Passport smart accounts on Midnight, built on an Account
Custody Contract (full architecture, key material and constraints in the
module's own
[README](../../packages/module/passport-account/README.md)). Alongside the
module factory, the `m` namespace exposes the seams it needs:

- `m.createPasskeyKeySource({ rpName? })`: owns the WebAuthn PRF ceremony and
  its key session; the authoriser and the encryption key below build on it.
- `m.createPasskeyAuthoriser({ keySource })`: the device signing authoriser.
- `m.createPasskeyEncryptionKey(keySource)`: the account encryption key over
  the same key source. It resolves only the X25519 public key the contract
  stores as `enc_key`; the secret never leaves the key source.
- `m.devEncryptionKey(seed?)`: an in-memory `PassportEncryptionKey` for
  development and tests, no passkey involved.
- `m.createDevSponsor(props)` and `m.createHttpProver(url, props)`: the
  development fee sponsor and proof-server client.

Build one key source and hand it to both the authoriser and the encryption
key, so a single passkey ceremony serves both:

```typescript
const keySource = m.createPasskeyKeySource({ rpName: 'My App' });
const authoriser = m.createPasskeyAuthoriser({ keySource });
const encryptionKey = m.createPasskeyEncryptionKey(keySource);

const wallet = await createLaceWallet({
  modules: [
    m.createPassportAccountModule({
      authoriser,
      encryptionKey,
      sponsor: m.createDevSponsor({
        /* ... */
      }),
      prover: m.createHttpProver('http://127.0.0.1:6300', {
        /* ... */
      }),
      network: {
        /* ... */
      },
    }),
  ] as const,
  environment: 'development',
  config: {
    /* see Configuration */
  },
});
```

### Usage

Pass modules to `createLaceWallet` using `as const` for full type inference:

```typescript
import { createLaceWallet, m } from '@input-output-hk/lace-sdk';

const wallet = await createLaceWallet({
  modules: [m.featureDev, m.storageInMemory, m.blockchainCardano, ...] as const,
  // ...
});
```

## Wallet API

### Passkey Cardano wallet (validated on Preprod)

Use the `/cardano` subpath for Cardano-only consumers. The root entry retains Passport exports for existing consumers and includes Passport runtime code; `/cardano` does not register Passport or Midnight modules.

This experimental recipe uses one WebAuthn PRF passkey to derive a 24-word wallet internally. There is no recovery-phrase export or phrase UI. Passkey derivation and signing have been validated on Preprod; mainnet has not been tested or guaranteed. Applications choose which Cardano networks to expose. The relying-party ID must match the app's origin; two localhost apps can share `rpId: 'localhost'`. A different origin needs its own credential. A passkey provider must support PRF and sync the same credential across devices.

The current SDK passkey loadout has no account-addition writer. Existing `addAccounts` integrations require an encrypted root or recovery phrase, which passkey entities do not store. The SDK returns supported Cardano accounts from the wallet integration; applications can select networks for their own use.

**Safe startup order:** Use `m.storageInMemory` for wallet state. Persist only `PasskeyWalletBinding` in separate application storage; do not persist or automatically rehydrate wallet entities before passkey verification. Load the binding, create a fresh empty SDK wallet, derive and compare its identity, then dispatch `wallets.addWallet`. Only then subscribe to balances or show the wallet UI. If the binding is missing after storage clear, require an explicit recovery choice before discovering a passkey and adding its entity. `storageWebIndexeddb` with automatic wallet-state rehydration is not a supported passkey startup path: balances may appear before the guard runs.

```typescript
import {
  createPasskeyKeySource,
  createPasskeyVaultModule,
  createPasskeyWalletEntity,
  createLaceWallet,
  FEATURE_FLAG_CARDANO,
  FEATURE_FLAG_NETWORK_TYPE,
  m,
} from '@input-output-hk/lace-sdk/cardano';

// On reopening, load savedBinding from app storage before creating the source.
const keySource = createPasskeyKeySource({
  rpId: 'localhost',
  credentialId: savedBinding?.credentialId,
});
const wallet = await createLaceWallet({
  modules: [
    m.featureDev,
    m.storageInMemory, // wallet state must start empty on every passkey login
    m.blockchainCardano,
    m.cardanoProviderBlockfrost,
    m.cryptoCardanoSdk,
    createPasskeyVaultModule({ keySource }),
  ] as const,
  environment: 'development',
  featureFlags: [
    { key: FEATURE_FLAG_CARDANO },
    { key: FEATURE_FLAG_NETWORK_TYPE, payload: 'testnet' },
  ],
  config: {
    /* Preprod Blockfrost config, see Configuration */
  },
});
// Only on explicit new-wallet creation: await keySource.ensureCredential().
// Without a stored binding, WebAuthn get() can discover a synced passkey.
const { entity, binding } = await createPasskeyWalletEntity(wallet, {
  keySource,
  walletName: 'Testnet wallet',
  expectedBinding: savedBinding,
});
// Persist only binding (credentialId, rpId, recipeVersion: 'v1', fingerprint).
// Add entity only after identity verification. A mismatch throws
// PasskeyWalletMismatchError before the app exposes balances or signing.
wallet.dispatch('wallets.addWallet', entity);
```

Creating a new credential asks once for registration and once for wallet derivation. Every transaction or data signature makes another assertion, including during an open Passport session. The SDK callbacks do not return mnemonic words, but `withPasskeyMnemonic` accepts a trusted application callback; TypeScript cannot prevent a malicious callback from retaining or returning words. Do not return or save them. Byte-array unlock passphrases are zeroed after use; JavaScript mnemonic strings cannot be reliably zeroed and become eligible for garbage collection when callbacks settle. Store the binding separately from wallet state and supply it on reload. A mismatched stored binding fails closed.

### Remote passkey signer

`createRemotePasskeySigner({ signerUrl })` connects to a Lace-hosted signer page instead of running WebAuthn in the dApp itself. The signer page owns the passkey and the sealed Passport account record; the dApp only ever exchanges public keys, commitments and signed results with it, over a `MessageChannel` to a popup window. Cardano signing supports mainnet and testnet, with the requested network shown for consent.

```typescript
import {
  createLaceWallet,
  createRemotePasskeySigner,
  m,
} from '@input-output-hk/lace-sdk';

// Development: the signer app's own dev server, http://localhost:5182 by default.
// Production: https://passkey.lace.io
const signer = createRemotePasskeySigner({
  signerUrl: 'http://localhost:5182',
});

button.addEventListener('click', async () => {
  // open() must run synchronously here: browsers refuse a popup opened
  // after an await, and Safari refuses a WebAuthn ceremony started from a
  // postMessage handler. connect() completes the handshake and can follow.
  signer.open();
  await signer.connect();

  const wallet = await createLaceWallet({
    modules: [
      m.blockchainCardano,
      m.cardanoProviderBlockfrost,
      m.cryptoCardanoSdk,
      signer.cardanoVaultModule,
      m.createPassportAccountModule({
        authoriser: signer.authoriser,
        encryptionKey: signer.encryptionKey,
        accountRecordStore: signer.accountRecordStore,
        sponsor: m.createDevSponsor({
          /* ... */
        }),
        prover: m.createHttpProver('http://127.0.0.1:6300', {
          /* ... */
        }),
        network: {
          /* ... */
        },
      }),
    ] as const,
    environment: 'development',
    config: {
      /* Preprod Blockfrost config, see Configuration */
    },
  });
});
```

`signer.authoriser`, `signer.encryptionKey` and `signer.accountRecordStore` wire straight into `createPassportAccountModule`; `signer.cardanoVaultModule` signs Cardano transactions and data the same way `createRemoteCardanoVaultModule` does. Call `signer.close()` to end the connection and close the popup.

The dApp persists nothing about the Passport account: the sealed record lives on the signer origin, never in application storage. One Approve click in the popup opens a key session for a whole Passport flow (create account, sign in, add a device); every Cardano transaction or data signature is its own Approve click and its own fresh assertion.

### Remote passkey Cardano wallet

A dApp on the hosted signer never sees the mnemonic, so it cannot derive its own Cardano wallet entity. `createRemotePasskeyWalletEntity` asks the signer for the extended public key of one account and builds the `LazyInMemory` wallet entity from that key alone; `signer.cardanoVaultModule` then signs for its accounts. The signer asks the user once to share the account; the key it returns is public, and the wallet id is derived from it. Mainnet, Preprod, and Preview accounts are returned; the dApp chooses which networks to expose.

```typescript
import {
  createLaceWallet,
  createRemotePasskeySigner,
  createRemotePasskeyWalletEntity,
  FEATURE_FLAG_CARDANO,
  FEATURE_FLAG_NETWORK_TYPE,
  m,
} from '@input-output-hk/lace-sdk/cardano';

const signer = createRemotePasskeySigner({
  signerUrl: 'http://localhost:5182',
});

button.addEventListener('click', async () => {
  signer.open();
  await signer.connect();

  const wallet = await createLaceWallet({
    modules: [
      m.featureDev,
      m.storageInMemory,
      m.blockchainCardano,
      m.cardanoProviderBlockfrost,
      m.cryptoCardanoSdk,
      signer.cardanoVaultModule,
    ] as const,
    environment: 'development',
    featureFlags: [
      { key: FEATURE_FLAG_CARDANO },
      { key: FEATURE_FLAG_NETWORK_TYPE, payload: 'testnet' },
    ],
    config: {
      /* Preprod Blockfrost config, see Configuration */
    },
  });

  // On reopening, load savedPublicKey from app storage; leave it undefined
  // the first time.
  const { entity, publicKey } = await createRemotePasskeyWalletEntity({
    signer,
    walletName: 'Testnet wallet',
    expectedPublicKey: savedPublicKey,
  });
  // Persist only publicKey: it is the public account identity, never a secret.
  // A signer that serves another account throws PasskeyWalletMismatchError
  // before any entity exists, so the app never shows a wallet that is not the saved one.
  wallet.dispatch('wallets.addWallet', entity);
});
```

The dApp persists only `publicKey`. Reopening compares the key the signer serves with `expectedPublicKey` and fails closed on a difference; without `expectedPublicKey` the helper opens whichever account the user shares. `accountIndex` selects another account of the same passkey (default `0`). `signer.accountPublicKey(accountIndex)` exposes the same request for apps that only need the key.

### Creating a wallet

After initializing the SDK, create a wallet entity from a BIP39 mnemonic:

```typescript
import { createInMemoryWalletEntity } from '@input-output-hk/lace-sdk';

const walletEntity = await createInMemoryWalletEntity(wallet, {
  mnemonicWords: ['abandon', 'abandon' /* ... 24 words */],
  password: new Uint8Array(Buffer.from('your-password')),
  walletName: 'My Wallet',
});

wallet.dispatch('wallets.addWallet', walletEntity);
```

For an external key source with no stored phrase, use `createLazyInMemoryVaultModule({ withMnemonicWords })`. The callback receives words for one signing operation and must await `use(words)` before it closes. Use `createPasskeyVaultModule` for passkey wallets, which compare the freshly derived account public key with the selected stored account before each signature.

### State observables

The wallet exposes RxJS observables for reactive state access:

```typescript
// All addresses across accounts
wallet.stateObservables.addresses.selectAllAddresses$.subscribe(addresses => {
  console.log(addresses.map(a => a.address));
});

// All token balances
wallet.stateObservables.tokens.selectAllTokens$.subscribe(tokens => {
  console.log(`${tokens.length} tokens`);
});
```

### Dispatching actions

Use the type-safe `dispatch` function with `"scope.actionName"` syntax:

```typescript
wallet.dispatch('wallets.addWallet', walletEntity);
```

### Reading state synchronously

```typescript
const state = wallet.getState();
```

## Deriving a Mnemonic from Entropy

`Mnemonic.deriveFrom(entropyHex)` deterministically derives a 24-word BIP39 mnemonic from any 32-byte hex-encoded entropy. It applies HKDF domain separation internally — the raw entropy is never used directly as wallet seed material.

The entropy can come from any source: a Web3Auth social login private key, a hardware security module, a KDF output, etc.

```typescript
import {
  EntropyHex,
  Mnemonic,
  createInMemoryWalletEntity,
} from '@input-output-hk/lace-sdk';

// Any 32-byte hex string (e.g., from Web3Auth, an HSM, or a KDF)
const entropyHex = EntropyHex('ab'.repeat(32)); // 64 hex chars = 32 bytes

const mnemonicWords = Mnemonic.deriveFrom(entropyHex);
// => Tagged<string[], 'Mnemonic'> — 24 BIP39 words

const walletEntity = await createInMemoryWalletEntity(wallet, {
  mnemonicWords,
  password: new Uint8Array(Buffer.from('your-password')),
  walletName: 'My Wallet',
});

wallet.dispatch('wallets.addWallet', walletEntity);
```

## Transaction Building

Build Cardano transactions using `TransactionBuilder`. The builder requires network info (chain ID and protocol parameters) that becomes available after the Cardano provider syncs.

```typescript
import { createTxBuilder, waitForNetworkInfo } from '@input-output-hk/lace-sdk';

// Wait for chain ID and protocol parameters to be available
await waitForNetworkInfo(wallet);

// Create a builder pre-configured with the active network
const builder = createTxBuilder(wallet).unwrap();

// Build a simple ADA transfer
const tx = builder
  .setChangeAddress(senderAddress)
  .setUnspentOutputs(availableUtxos)
  .transferValue(recipientAddress, { coins: 1_230_000n })
  .expiresIn(900)
  .build();

// Serialize to CBOR hex
const cborHex = tx.toCbor();
```

`waitForNetworkInfo(wallet)` resolves once the provider has fetched protocol parameters — call it before `createTxBuilder` to guarantee success. `createTxBuilder` returns a `Result<TransactionBuilder, Error>` so callers can handle the not-ready case without exceptions.

### Plutus smart contracts

`TransactionBuilder` expresses the **full** Cardano transaction domain — simple transfers, certificates, and Plutus spends (mint, script-spend, script-withdrawal with redeemers, collateral, required signers). For Plutus transactions, supply a `PlutusContext` (full protocol cost models, an execution-units evaluator, and an input resolver) via `setPlutusContext` before `build()`. `build()` selects inputs, balances, evaluates ex-units, and computes the script-data-hash, returning an **unsigned** transaction:

```typescript
const tx = await builder
  .setChangeAddress(changeAddress)
  .setUnspentOutputs(coverUtxos)
  .setPlutusContext({ costModels, txEvaluator, inputResolver })
  .attachScript(plutusScript)
  .mintAssets(new Map([[assetId, 1n]]), redeemer)
  .setCollateral([collateralInput], collateralReturn)
  .addRequiredSigner(paymentKeyHash)
  .build();

// tx.toCbor() is unsigned — hand it to signCardanoTx → submitCardanoTx
```

`build()` is async only because Plutus ex-units evaluation is async; non-Plutus builds resolve synchronously.

## Transaction Signing

Sign a Cardano transaction using an in-memory wallet without the authentication prompt UI:

```typescript
import { signCardanoTx } from '@input-output-hk/lace-sdk';

const result = await signCardanoTx(wallet, {
  serializedTx: cborHex,
  password: new Uint8Array(Buffer.from('your-password')),
  // accountId is optional — required only when multiple Cardano
  // in-memory accounts exist on the active network
});

if (result.isOk()) {
  console.log('Signed tx:', result.value);
} else {
  console.error('Signing failed:', result.error.message);
}
```

`password` is optional at the type level to allow extending to other wallet types (e.g. Ledger) in the future, but is required at runtime for in-memory wallets.

Resolves with `Result<CardanoSignResult, Error>` — never rejects.

## Transaction Submission

Submit a signed Cardano transaction to the network:

```typescript
import { submitCardanoTx } from '@input-output-hk/lace-sdk';

const result = await submitCardanoTx(wallet, {
  serializedTx: signedCborHex,
});

if (result.isOk()) {
  console.log('Transaction submitted:', result.value.txId);
} else {
  console.error('Submission failed:', result.error.message);
}
```

Resolves with `Result<{ txId: Cardano.TransactionId }, Error>` — never rejects.

## Complete Example

A working SDK consumer is available at [`lace-sdk-consumer`](https://github.com/mkazlauskas/lace-sdk-consumer).

For a Passport account module example that runs against a local Midnight network from inside this repository, see [`apps/lace-sdk-example-passport`](../lace-sdk-example-passport/README.md).

## API Reference

### Functions

| Function                                    | Description                                                      |
| ------------------------------------------- | ---------------------------------------------------------------- |
| `createLaceWallet(props)`                   | Create a headless wallet instance with modules and config        |
| `createInMemoryWalletEntity(wallet, props)` | Create a password-protected wallet entity from a mnemonic        |
| `Mnemonic.deriveFrom(entropyHex)`           | Derive a 24-word BIP39 mnemonic from hex-encoded entropy         |
| `createTxBuilder(wallet)`                   | Create a `TransactionBuilder` from wallet state (Plutus-capable) |
| `waitForNetworkInfo(wallet)`                | Wait for Cardano network info to be available                    |
| `signCardanoTx(wallet, props)`              | Sign a Cardano transaction with an in-memory wallet              |
| `submitCardanoTx(wallet, props)`            | Submit a signed Cardano transaction to the network               |

### Types

| Type                              | Description                                                                          |
| --------------------------------- | ------------------------------------------------------------------------------------ |
| `LaceWallet`                      | Wallet instance with `dispatch`, `getState`, `stateObservables`, `actionObservables` |
| `CreateLaceWalletProps`           | Options for `createLaceWallet`: `modules`, `environment`, `config`, `featureFlags`   |
| `CreateInMemoryWalletEntityProps` | Options: `mnemonicWords`, `password` (Uint8Array), `walletName`, `order?`            |
| `AppConfig`                       | Application configuration (Blockfrost, polling intervals, explorer URLs)             |
| `FeatureFlag`                     | Feature flag entry: `{ key: FeatureFlagKey, payload?: string }`                      |
| `SignCardanoTxProps`              | Options: `serializedTx`, `password?` (Uint8Array), `accountId?`                      |
| `CardanoSignResult`               | Signing result with witness set                                                      |
| `SubmitCardanoTxProps`            | Options: `serializedTx` (HexBytes)                                                   |

### Value Objects

Time utilities with nominal typing (zero runtime overhead):

```typescript
import {
  Milliseconds,
  Seconds,
  Minutes,
  Hours,
  Days,
  Timestamp,
  TimeSpan,
} from '@input-output-hk/lace-sdk';
```

Other value objects: `BigNumber`, `HexBytes`, `ByteArray`, `Uri`

### Feature Flags

| Flag                        | Purpose                                               |
| --------------------------- | ----------------------------------------------------- |
| `FEATURE_FLAG_CARDANO`      | Enable Cardano blockchain support                     |
| `FEATURE_FLAG_NETWORK_TYPE` | Set default network type (`'mainnet'` or `'testnet'`) |

## License

Apache-2.0
