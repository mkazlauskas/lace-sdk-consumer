# @input-output-hk/lace-sdk

Headless SDK for the Lace wallet platform. Create and manage Cardano wallets with passkeys or other key sources, reactive state observables, and a modular architecture.

## Installation

The package is published to [GitHub Packages](https://github.com/input-output-hk/lace-platform/packages). You need to configure npm to use the GitHub registry for the `@input-output-hk` scope.

### 1. Authenticate with GitHub Packages

Create a [personal access token](https://github.com/settings/tokens) (classic) with `read:packages` scope, then log in:

```bash
npm login --scope=@input-output-hk --registry=https://npm.pkg.github.com
```

Or add it directly to your project's `.npmrc`:

```ini
# .npmrc
@input-output-hk:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=YOUR_GITHUB_TOKEN
```

### 2. Install

```bash
npm install @input-output-hk/lace-sdk
```

> **Note:** Published versions use the `dev` dist-tag (e.g., `0.1.0-dev.42`). To install the latest dev release:
>
> ```bash
> npm install @input-output-hk/lace-sdk@dev
> ```

### 3. TypeScript

The bundled declarations take types from `@cardano-sdk/core`, `@cardano-sdk/crypto`, `@cardano-sdk/util`, `ts-results-es`, `type-fest` and a few other packages. The SDK depends on each of them at the exact version its bundle is built from, so `Cardano`, `HexBlob`, `Result` and the custody types resolve without extra installs. The bundle carries its own copy of their code; the installed packages serve only the types.

A project that depends on another `@cardano-sdk/core` version gets a separate copy for the SDK. Values such as a `Cardano.PaymentAddress` or a `Cardano.Utxo` that the project builds with an older `@cardano-sdk/core` can be passed to the SDK. Values the SDK returns are typed by the `@cardano-sdk/core` version in the SDK's `dependencies`, 0.47.1, and may not assign to the older types: type them with the SDK's `Cardano` export, or align the project on that version. Class instances such as `Serialization.Transaction` do not pass between the two copies, so create them from the SDK's `Serialization` export.

The declarations also import React, React Native, Expo SecureStore, React Navigation, `history`, `i18next`, `webextension-polyfill`, the Midnight wallet packages and `@blockfrost/blockfrost-js`, which the SDK does not depend on. Their types are `any` unless the project installs those packages. The declarations of the SDK and of `@cardano-sdk/*` do not pass a full type check, so compile with `skipLibCheck: true`.

## Quick Start

```typescript
import {
  createLaceWallet,
  FEATURE_FLAG_CARDANO,
  FEATURE_FLAG_NETWORK_TYPE,
  m,
} from '@input-output-hk/lace-sdk/cardano';

const wallet = await createLaceWallet({
  modules: [
    m.featureDev,
    m.storageInMemory,
    m.blockchainCardano,
    m.cardanoProviderBlockfrost,
    m.cryptoCardanoSdk,
  ] as const,
  environment: 'development',
  featureFlags: [
    { key: FEATURE_FLAG_CARDANO },
    { key: FEATURE_FLAG_NETWORK_TYPE, payload: 'testnet' },
  ],
  config: {
    /* see Configuration */
  },
});

// Subscribe to reactive state
wallet.stateObservables.addresses.selectAllAddresses$.subscribe(addresses => {
  console.log('Addresses:', addresses);
});

wallet.stateObservables.tokens.selectAllTokens$.subscribe(tokens => {
  console.log('Tokens:', tokens);
});

// Read state synchronously
const state = wallet.getState();
```

## Configuration

The SDK requires an `AppConfig` object with Blockfrost provider credentials and network settings.

```typescript
import {
  Cardano,
  FEATURE_FLAG_CARDANO,
  FEATURE_FLAG_NETWORK_TYPE,
  Milliseconds,
  type AppConfig,
} from '@input-output-hk/lace-sdk/cardano';

const featureFlags = [
  { key: FEATURE_FLAG_CARDANO },
  { key: FEATURE_FLAG_NETWORK_TYPE, payload: 'testnet' },
];

const config: Partial<AppConfig> = {
  defaultFeatureFlags: featureFlags,
  extraFeatureFlags: [],
  defaultTestnetChainId: Cardano.ChainIds.Preprod,
  cardanoProvider: {
    tipPollFrequency: Milliseconds(30_000),
    blockfrostConfigs: {
      // Keyed by Cardano network magic
      1: {
        clientConfig: {
          baseUrl: 'https://cardano-preprod.blockfrost.io',
          apiVersion: 'v0',
          projectId: 'YOUR_PREPROD_PROJECT_ID',
        },
        rateLimiterConfig: {
          size: 500,
          increaseAmount: 10,
          increaseInterval: Milliseconds(1000),
        },
      },
      2: {
        clientConfig: {
          baseUrl: 'https://cardano-preview.blockfrost.io',
          apiVersion: 'v0',
          projectId: 'YOUR_PREVIEW_PROJECT_ID',
        },
        rateLimiterConfig: {
          size: 500,
          increaseAmount: 10,
          increaseInterval: Milliseconds(1000),
        },
      },
      764824073: {
        clientConfig: {
          baseUrl: 'https://cardano-mainnet.blockfrost.io',
          apiVersion: 'v0',
          projectId: 'YOUR_MAINNET_PROJECT_ID',
        },
        rateLimiterConfig: {
          size: 500,
          increaseAmount: 10,
          increaseInterval: Milliseconds(1000),
        },
      },
    },
  },
  cexplorerUrls: {
    1: 'https://preprod.cexplorer.io',
    2: 'https://preview.cexplorer.io',
    764824073: 'https://cexplorer.io',
  },
};
```

## Modules

The SDK uses a modular architecture. Pre-configured modules are available via the `m` namespace export:

### Feature Flags — `featureDev`

Static, in-memory feature flag evaluation. Feature flags are set at initialization time and remain fixed for the lifetime of the wallet. Suitable for development, testing, and applications where flags are known at build time.

**Platform alternative (not yet in SDK):** `feature-posthog` — evaluates flags dynamically via [PostHog](https://posthog.com/), allowing remote flag updates without redeploying.

### Storage — `storageInMemory`

Ephemeral in-memory key-value storage. State is lost when the process exits. Useful for serverless, testing, or short-lived sessions where persistence is not needed.

**Platform alternatives (not yet in SDK):**

- `storage-extension` — persists to `chrome.storage.local` (browser extensions)
- `storage-react-native-async` — persists to React Native AsyncStorage (mobile)

### Blockchain — `blockchainCardano`

Full Cardano blockchain integration: address discovery, UTXO management, token tracking, transaction building, delegation, and in-memory wallet signing.

When Cardano feature is active, the SDK also loads the headless Cardano sync executor. Adding a verified wallet starts address discovery; UTXO sync follows discovered addresses. `requestManualAddressDiscovery` then has a handler for thorough rescans.

**Platform alternatives (not yet in SDK):**

- `blockchain-bitcoin` — Bitcoin UTXO model, address validation, fee estimation
- `blockchain-midnight` — Midnight privacy blockchain with shielded contracts

Multiple blockchain modules can be loaded simultaneously — the wallet manages accounts across all active chains.

### Provider — `cardanoProviderBlockfrost`

Fetches on-chain Cardano data (UTXOs, transactions, stake info, network parameters) via the [Blockfrost](https://blockfrost.io/) API. Requires a Blockfrost project ID per network.

### Cryptography — `cryptoCardanoSdk`

Provides `bip32Ed25519` key derivation and `blake2b` hashing using the `@cardano-sdk` library.

**Platform alternative (not yet in SDK):** `crypto-apollo` — same cryptographic interface backed by the Apollo library.

### Passport (`createPassportAccountModule`)

Passkey-backed Passport smart accounts on Midnight, built on an Account
Custody Contract (full architecture, key material and constraints in the
module's own
[README](../../packages/module/passport-account/README.md)). Alongside the
module factory, the `m` namespace exposes the seams it needs:

- `m.createPasskeyKeySource({ rpName? })`: owns the WebAuthn PRF ceremony and
  its key session; the authoriser and the encryption key below build on it.
- `m.createPasskeyAuthoriser({ keySource })`: the device signing authoriser.
- `m.createPasskeyEncryptionKey(keySource)`: the account encryption key over
  the same key source. It resolves only the X25519 public key the contract
  stores as `enc_key`; the secret never leaves the key source.
- `m.devEncryptionKey(seed?)`: an in-memory `PassportEncryptionKey` for
  development and tests, no passkey involved.
- `m.createDevSponsor(props)` and `m.createHttpProver(url, props)`: the
  development fee sponsor and proof-server client.

Build one key source and hand it to both the authoriser and the encryption
key, so a single passkey ceremony serves both:

```typescript
const keySource = m.createPasskeyKeySource({ rpName: 'My App' });
const authoriser = m.createPasskeyAuthoriser({ keySource });
const encryptionKey = m.createPasskeyEncryptionKey(keySource);

const wallet = await createLaceWallet({
  modules: [
    m.createPassportAccountModule({
      authoriser,
      encryptionKey,
      sponsor: m.createDevSponsor({
        /* ... */
      }),
      prover: m.createHttpProver('http://127.0.0.1:6300', {
        /* ... */
      }),
      network: {
        /* ... */
      },
    }),
  ] as const,
  environment: 'development',
  config: {
    /* see Configuration */
  },
});
```

### Usage

Pass modules to `createLaceWallet` using `as const` for full type inference:

```typescript
import { createLaceWallet, m } from '@input-output-hk/lace-sdk';

const wallet = await createLaceWallet({
  modules: [m.featureDev, m.storageInMemory, m.blockchainCardano, ...] as const,
  // ...
});
```

## Wallet API

### Passkey Cardano wallet (validated on Preprod)

Use the `/cardano` subpath for Cardano-only consumers. The root entry retains Passport exports for existing consumers and includes Passport runtime code; `/cardano` does not register Passport or Midnight modules.

This experimental recipe uses one WebAuthn PRF passkey to derive a 24-word wallet internally. There is no recovery-phrase export or phrase UI. Passkey derivation and signing have been validated on Preprod; mainnet has not been tested or guaranteed. Applications choose which Cardano networks to expose. The relying-party ID must match the app's origin; two localhost apps can share `rpId: 'localhost'`. A different origin needs its own credential. A passkey provider must support PRF and sync the same credential across devices.

The current SDK passkey loadout has no account-addition writer. Existing `addAccounts` integrations require an encrypted root or recovery phrase, which passkey entities do not store. The SDK returns supported Cardano accounts from the wallet integration; applications can select networks for their own use.

**Safe startup order:** Use `m.storageInMemory` for wallet state. Persist only `PasskeyWalletBinding` in separate application storage; do not persist or automatically rehydrate wallet entities before passkey verification. Load the binding, create a fresh empty SDK wallet, derive and compare its identity, then dispatch `wallets.addWallet`. Only then subscribe to balances or show the wallet UI. If the binding is missing after storage clear, require an explicit recovery choice before discovering a passkey and adding its entity. `storageWebIndexeddb` with automatic wallet-state rehydration is not a supported passkey startup path: balances may appear before the guard runs.

```typescript
import {
  createPasskeyKeySource,
  createPasskeyVaultModule,
  createPasskeyWalletEntity,
  createLaceWallet,
  FEATURE_FLAG_CARDANO,
  FEATURE_FLAG_NETWORK_TYPE,
  m,
} from '@input-output-hk/lace-sdk/cardano';

// On reopening, load savedBinding from app storage before creating the source.
const keySource = createPasskeyKeySource({
  rpId: 'localhost',
  credentialId: savedBinding?.credentialId,
});
const wallet = await createLaceWallet({
  modules: [
    m.featureDev,
    m.storageInMemory, // wallet state must start empty on every passkey login
    m.blockchainCardano,
    m.cardanoProviderBlockfrost,
    m.cryptoCardanoSdk,
    createPasskeyVaultModule({ keySource }),
  ] as const,
  environment: 'development',
  featureFlags: [
    { key: FEATURE_FLAG_CARDANO },
    { key: FEATURE_FLAG_NETWORK_TYPE, payload: 'testnet' },
  ],
  config: {
    /* Preprod Blockfrost config, see Configuration */
  },
});
// Only on explicit new-wallet creation: await keySource.ensureCredential().
// Without a stored binding, WebAuthn get() can discover a synced passkey.
const { entity, binding } = await createPasskeyWalletEntity(wallet, {
  keySource,
  walletName: 'Testnet wallet',
  expectedBinding: savedBinding,
});
// Persist only binding (credentialId, rpId, recipeVersion: 'v1', fingerprint).
// Add entity only after identity verification. A mismatch throws
// PasskeyWalletMismatchError before the app exposes balances or signing.
wallet.dispatch('wallets.addWallet', entity);
```

Creating a new credential asks once for registration and once for wallet derivation. Every transaction or data signature makes another assertion, including during an open Passport session. The SDK callbacks do not return mnemonic words, but `withPasskeyMnemonic` accepts a trusted application callback; TypeScript cannot prevent a malicious callback from retaining or returning words. Do not return or save them. Byte-array unlock passphrases are zeroed after use; JavaScript mnemonic strings cannot be reliably zeroed and become eligible for garbage collection when callbacks settle. Store the binding separately from wallet state and supply it on reload. A mismatched stored binding fails closed.

### Remote passkey signer

`createRemotePasskeySigner({ signerUrl })` connects to a Lace-hosted signer page instead of running WebAuthn in the dApp itself. The signer page owns the passkey and the sealed Passport account record; the dApp only ever exchanges public keys, commitments and signed results with it, over a `MessageChannel` to a popup window. Cardano signing supports mainnet and testnet, with the requested network shown for consent.

```typescript
import {
  createLaceWallet,
  createRemotePasskeySigner,
  m,
} from '@input-output-hk/lace-sdk';

// Development: the signer app's own dev server, http://localhost:5182 by default.
// Production: https://passkey.lace.io
const signer = createRemotePasskeySigner({
  signerUrl: 'http://localhost:5182',
});

button.addEventListener('click', async () => {
  // open() must run synchronously here: browsers refuse a popup opened
  // after an await, and Safari refuses a WebAuthn ceremony started from a
  // postMessage handler. connect() completes the handshake and can follow.
  signer.open();
  await signer.connect();

  const wallet = await createLaceWallet({
    modules: [
      m.blockchainCardano,
      m.cardanoProviderBlockfrost,
      m.cryptoCardanoSdk,
      signer.cardanoVaultModule,
      m.createPassportAccountModule({
        authoriser: signer.authoriser,
        encryptionKey: signer.encryptionKey,
        accountRecordStore: signer.accountRecordStore,
        sponsor: m.createDevSponsor({
          /* ... */
        }),
        prover: m.createHttpProver('http://127.0.0.1:6300', {
          /* ... */
        }),
        network: {
          /* ... */
        },
      }),
    ] as const,
    environment: 'development',
    config: {
      /* Preprod Blockfrost config, see Configuration */
    },
  });
});
```

`signer.authoriser`, `signer.encryptionKey` and `signer.accountRecordStore` wire straight into `createPassportAccountModule`; `signer.cardanoVaultModule` signs Cardano transactions and data the same way `createRemoteCardanoVaultModule` does. Call `signer.close()` to end the connection and close the popup.

The dApp persists nothing about the Passport account: the sealed record lives on the signer origin, never in application storage. One Approve click in the popup opens a key session for a whole Passport flow (create account, sign in, add a device); every Cardano transaction or data signature is its own Approve click and its own fresh assertion.

### Remote passkey Cardano wallet

A dApp on the hosted signer never sees the mnemonic, so it cannot derive its own Cardano wallet entity. `createRemotePasskeyWalletEntity` asks the signer for the extended public key of one account and builds the `LazyInMemory` wallet entity from that key alone; `signer.cardanoVaultModule` then signs for its accounts. The signer asks the user once to share the account; the key it returns is public, and the wallet id is derived from it. Mainnet, Preprod, and Preview accounts are returned; the dApp chooses which networks to expose.

```typescript
import {
  createLaceWallet,
  createRemotePasskeySigner,
  createRemotePasskeyWalletEntity,
  FEATURE_FLAG_CARDANO,
  FEATURE_FLAG_NETWORK_TYPE,
  m,
} from '@input-output-hk/lace-sdk/cardano';

const signer = createRemotePasskeySigner({
  signerUrl: 'http://localhost:5182',
});

button.addEventListener('click', async () => {
  signer.open();
  await signer.connect();

  const wallet = await createLaceWallet({
    modules: [
      m.featureDev,
      m.storageInMemory,
      m.blockchainCardano,
      m.cardanoProviderBlockfrost,
      m.cryptoCardanoSdk,
      signer.cardanoVaultModule,
    ] as const,
    environment: 'development',
    featureFlags: [
      { key: FEATURE_FLAG_CARDANO },
      { key: FEATURE_FLAG_NETWORK_TYPE, payload: 'testnet' },
    ],
    config: {
      /* Preprod Blockfrost config, see Configuration */
    },
  });

  // On reopening, load savedPublicKey from app storage; leave it undefined
  // the first time.
  const { entity, publicKey } = await createRemotePasskeyWalletEntity({
    signer,
    walletName: 'Testnet wallet',
    expectedPublicKey: savedPublicKey,
  });
  // Persist only publicKey: it is the public account identity, never a secret.
  // A signer that serves another account throws PasskeyWalletMismatchError
  // before any entity exists, so the app never shows a wallet that is not the saved one.
  wallet.dispatch('wallets.addWallet', entity);
});
```

The dApp persists only `publicKey`. Reopening compares the key the signer serves with `expectedPublicKey` and fails closed on a difference; without `expectedPublicKey` the helper opens whichever account the user shares. `accountIndex` selects another account of the same passkey (default `0`). `signer.accountPublicKey(accountIndex)` exposes the same request for apps that only need the key.

### Creating a wallet

After initializing the SDK, create a wallet entity from a BIP39 mnemonic:

```typescript
import { createInMemoryWalletEntity } from '@input-output-hk/lace-sdk';

const walletEntity = await createInMemoryWalletEntity(wallet, {
  mnemonicWords: ['abandon', 'abandon' /* ... 24 words */],
  password: new Uint8Array(Buffer.from('your-password')),
  walletName: 'My Wallet',
});

wallet.dispatch('wallets.addWallet', walletEntity);
```

For an external key source with no stored phrase, use `createLazyInMemoryVaultModule({ withMnemonicWords })`. The callback receives words for one signing operation and must await `use(words)` before it closes. Use `createPasskeyVaultModule` for passkey wallets, which compare the freshly derived account public key with the selected stored account before each signature.

### State observables

The wallet exposes RxJS observables for reactive state access:

```typescript
// All addresses across accounts
wallet.stateObservables.addresses.selectAllAddresses$.subscribe(addresses => {
  console.log(addresses.map(a => a.address));
});

// All token balances
wallet.stateObservables.tokens.selectAllTokens$.subscribe(tokens => {
  console.log(`${tokens.length} tokens`);
});
```

### Dispatching actions

Use the type-safe `dispatch` function with `"scope.actionName"` syntax:

```typescript
wallet.dispatch('wallets.addWallet', walletEntity);
```

### Reading state synchronously

```typescript
const state = wallet.getState();
```

## Deriving a Mnemonic from Entropy

`Mnemonic.deriveFrom(entropyHex)` deterministically derives a 24-word BIP39 mnemonic from any 32-byte hex-encoded entropy. It applies HKDF domain separation internally — the raw entropy is never used directly as wallet seed material.

The entropy can come from any source: a Web3Auth social login private key, a hardware security module, a KDF output, etc.

```typescript
import {
  EntropyHex,
  Mnemonic,
  createInMemoryWalletEntity,
} from '@input-output-hk/lace-sdk';

// Any 32-byte hex string (e.g., from Web3Auth, an HSM, or a KDF)
const entropyHex = EntropyHex('ab'.repeat(32)); // 64 hex chars = 32 bytes

const mnemonicWords = Mnemonic.deriveFrom(entropyHex);
// => Tagged<string[], 'Mnemonic'> — 24 BIP39 words

const walletEntity = await createInMemoryWalletEntity(wallet, {
  mnemonicWords,
  password: new Uint8Array(Buffer.from('your-password')),
  walletName: 'My Wallet',
});

wallet.dispatch('wallets.addWallet', walletEntity);
```

## Transaction Building

Build Cardano transactions using `TransactionBuilder`. The builder requires network info (chain ID and protocol parameters) that becomes available after the Cardano provider syncs.

```typescript
import { createTxBuilder, waitForNetworkInfo } from '@input-output-hk/lace-sdk';

// Wait for chain ID and protocol parameters to be available
await waitForNetworkInfo(wallet);

// Create a builder pre-configured with the active network
const builder = createTxBuilder(wallet).unwrap();

// Build a simple ADA transfer
const tx = builder
  .setChangeAddress(senderAddress)
  .setUnspentOutputs(availableUtxos)
  .transferValue(recipientAddress, { coins: 1_230_000n })
  .expiresIn(900)
  .build();

// Serialize to CBOR hex
const cborHex = tx.toCbor();
```

`waitForNetworkInfo(wallet)` resolves once the provider has fetched protocol parameters — call it before `createTxBuilder` to guarantee success. `createTxBuilder` returns a `Result<TransactionBuilder, Error>` so callers can handle the not-ready case without exceptions.

### Plutus smart contracts

`TransactionBuilder` expresses the **full** Cardano transaction domain — simple transfers, certificates, and Plutus spends (mint, script-spend, script-withdrawal with redeemers, collateral, required signers). For Plutus transactions, supply a `PlutusContext` (full protocol cost models, an execution-units evaluator, and an input resolver) via `setPlutusContext` before `build()`. `build()` selects inputs, balances, evaluates ex-units, and computes the script-data-hash, returning an **unsigned** transaction:

```typescript
const tx = await builder
  .setChangeAddress(changeAddress)
  .setUnspentOutputs(coverUtxos)
  .setPlutusContext({ costModels, txEvaluator, inputResolver })
  .attachScript(plutusScript)
  .mintAssets(new Map([[assetId, 1n]]), redeemer)
  .setCollateral([collateralInput], collateralReturn)
  .addRequiredSigner(paymentKeyHash)
  .build();

// tx.toCbor() is unsigned — hand it to signCardanoTx → submitCardanoTx
```

`build()` is async only because Plutus ex-units evaluation is async; non-Plutus builds resolve synchronously.

## Transaction Signing

Sign a Cardano transaction using an in-memory wallet without the authentication prompt UI:

```typescript
import { signCardanoTx } from '@input-output-hk/lace-sdk';

const result = await signCardanoTx(wallet, {
  serializedTx: cborHex,
  password: new Uint8Array(Buffer.from('your-password')),
  // accountId is optional — required only when multiple Cardano
  // in-memory accounts exist on the active network
});

if (result.isOk()) {
  console.log('Signed tx:', result.value);
} else {
  console.error('Signing failed:', result.error.message);
}
```

`password` is optional at the type level to allow extending to other wallet types (e.g. Ledger) in the future, but is required at runtime for in-memory wallets.

Resolves with `Result<CardanoSignResult, Error>` — never rejects.

## Transaction Submission

Submit a signed Cardano transaction to the network:

```typescript
import { submitCardanoTx } from '@input-output-hk/lace-sdk';

const result = await submitCardanoTx(wallet, {
  serializedTx: signedCborHex,
});

if (result.isOk()) {
  console.log('Transaction submitted:', result.value.txId);
} else {
  console.error('Submission failed:', result.error.message);
}
```

Resolves with `Result<{ txId: Cardano.TransactionId }, Error>` — never rejects.

## Cardano custody account

A Cardano custody account is a script account at a permanent address of the [Cardano account custody contract](https://github.com/Biglup/cardano-account-custody-contract/tree/b48545f4be850c1044de2dbeb51751718b4b8e70). Passkey-derived device keys own it, and external agents spend from it under on-chain grants. [ADR 65](../../docs/adr/65-cardano-custody-account.md) records the design and has the tables of where each restriction is enforced, who builds, signs and submits each transaction, and who pays for it.

> **Warning:** The custody contract is unaudited, and its author describes it as testnet-only. The SDK allows custody accounts on every network, Mainnet included, so refusing Mainnet is the application's decision. The hosted fee sponsor service runs on Preprod only, so Mainnet also needs a Mainnet sponsor.

### Concepts

- **Account.** One account per creator key and network, at an address that never changes. Its control UTxO holds a state NFT and an inline datum: the logic the account runs, 1 to 8 device key hashes, the grant generation, the next grant slot, up to 32 revoked slots and the count of outstanding grants. An account cannot be closed: the stake deposit and the control output's minimum lovelace stay locked for its life.
- **Logic.** The account's rules live in a logic script its control datum names. The account proxy, whose hash is `CARDANO_CUSTODY_ACCOUNT_VALIDATOR_HASH`, is the payment script of every account UTxO and runs that logic in every transaction but a plain deposit, through a withdrawal from the logic's reward account. That withdrawal must take the reward account's whole balance, which is normally zero and which anyone can add to. On Preprod, transactions read the proxy and the logic from UTxOs that park them there; on any other network they carry both scripts. The SDK accepts only the logics in `CARDANO_CUSTODY_LOGIC_HASHES`, and new accounts run `CARDANO_CUSTODY_LOGIC_HASH`. An account under any other logic is `invalid` with the reason `unknown-logic`: its balances still show, and the SDK runs no operation and signs nothing for it. The SDK never changes an account's logic.
- **Devices.** Every listed device key has full owner authority: it lists and removes devices, issues, revokes and removes grants, spends account funds, delegates stake and withdraws rewards. A device key is `m/1854'/1815'/a'/0/i` (CIP-1854) from the passkey's words, with `a` = 0 on Mainnet and 1 on every testnet. A passkey belongs to its relying party, so a credential the app holds, the hosted signer and each signer hostname are different devices. Synced copies of one passkey are one device.
- **Grants.** A grant lets one agent Ed25519 key, the grantee, spend one asset (lovelace or one token) from the account: `perCallCap` per spend and `cap` in total, until `expiresAt` (POSIX milliseconds), to `recipients` (empty allows any address). A token grant also caps the lovelace a spend takes with `lovelacePerCallCap` and `lovelaceCap`; a lovelace grant sets both to zero. The caps bound the net outflow from the account, fees included, and the remaining caps fall with every spend. Each grant lives in its own grant UTxO at the account address, which holds a grant token named after its `slot` and the grant as its inline datum. A slot identifies one grant for its lifetime and is never reused; replacement issues a new grant in a new slot. The account's logic enforces every grant limit on chain.
- **Grant lifetime.** A grant stops working when a device revokes its slot, when a revoke-all raises the grant generation past it, or when it expires. A grant that stopped working still counts toward the 16 outstanding grants and holds its lovelace until a sweep removes it.
- **Balances.** The account address holds the control UTxO, grant UTxOs, plain funds, reserves (deposits under an inline datum, which agents never spend) and stranded deposits under a datum hash, which nobody can spend. Owner operations spend only own reserves, which carry the datum `d87980` and no reference script, and plain funds without a reference script. Agents spend plain funds only. The control output's lovelace above its ledger minimum is the owner fee reserve: an owner operation takes its fee from there when its own reserves and its plain funds without a reference script cannot pay it.
- **Observer mode.** An account opened without a device binding is an observer, such as an agent: it syncs and builds grant spends, but runs no owner operation and names no deposit address. An account whose state no longer lists the bound device behaves the same way.
- **Sponsor modes.** Every custody transaction runs a script and needs collateral, which the fee sponsor provides through `CardanoCustodySponsor`. Creation runs in fee mode, which serves creation alone: a leased sponsor UTxO pays the fee, the stake deposit and the control output. Every later transaction runs in collateral mode: the account pays its own fee, and the sponsor lends only its shared collateral UTxO. Self-funded creation, paid from a wallet the app controls, is deferred: sponsored creation is all the first integration needs, and the hosted Preprod sponsor serves it.

Custody UTxOs never reach `signCardanoTx`, `createTxBuilder` or any other generic UTxO selection.

### Contract revision

The SDK supports one build of the custody contract, revision [`b48545f`](https://github.com/Biglup/cardano-account-custody-contract/tree/b48545f4be850c1044de2dbeb51751718b4b8e70), whose account proxy hash is `CARDANO_CUSTODY_ACCOUNT_VALIDATOR_HASH`, and mirrors the rules of the fee sponsor at revision [`4de7a38`](https://github.com/Biglup/cardano-account-custody-fee-sponsor/tree/4de7a3812af99c631870724a0633f6250ed4f23a). Accounts of any other contract build have other addresses: `parseCardanoCustodyAccountRecord` refuses their records with `CardanoCustodyUnsupportedVersionError`, and recovery does not find them. Send no deposit to an address of another build.

- **The logic.** `state.logic` names the logic the account runs. `CardanoCustodyInvalidReason` includes `unknown-logic`, which an exhaustive `switch` must handle, and `account-not-live` refusals carry the `invalid` reason in `detail.reason`.
- **The logic's errors.** `CardanoCustodyLogicNotRegisteredError`, `CardanoCustodyLogicRewardBalanceError`, `CardanoCustodyLogicNotServedError`, `CardanoCustodyScriptDataHashError` and `CardanoCustodyRewardBalanceChangedError` (see [Errors](#errors)).
- **The logic run.** Every account transaction but a plain deposit withdraws from the logic's reward account, and on Preprod reads the proxy and the logic from reference inputs. A grant spend carries that withdrawal at zero.

### Setup

Create the wallet with the Cardano modules (see [Configuration](#configuration)), then build the sponsor client and a device signer. The `/cardano` subpath and the root entry export the same custody API.

```typescript
import {
  Cardano,
  createCardanoCustodySponsorClient,
  createLaceWallet,
  createRemoteCardanoCustodyDeviceSigner,
  createRemotePasskeySigner,
  FEATURE_FLAG_CARDANO,
  FEATURE_FLAG_NETWORK_TYPE,
  m,
  requestCardanoCustodyDeviceKey,
} from '@input-output-hk/lace-sdk/cardano';

const wallet = await createLaceWallet({
  modules: [
    m.featureDev,
    m.storageInMemory,
    m.blockchainCardano,
    m.cardanoProviderBlockfrost,
    m.cryptoCardanoSdk,
  ] as const,
  environment: 'development',
  featureFlags: [
    { key: FEATURE_FLAG_CARDANO },
    { key: FEATURE_FLAG_NETWORK_TYPE, payload: 'testnet' },
  ],
  config: {
    /* Preprod Blockfrost config, see Configuration */
  },
});
// A relay on the app's own backend adds the sponsor API key (see Fee sponsor).
const sponsor = createCardanoCustodySponsorClient({
  baseUrl: 'https://app.example/sponsor',
});
```

The custody helpers are safe to call right after `createLaceWallet`. Helpers that read the wallet's network wait up to 30 seconds for it, and helpers that build a transaction also wait for the era summaries the provider loads. When either is missing in time, they fail with `CardanoCustodyNetworkNotReadyError`, whose `missing` is `network` or `era-summaries`.

### Device keys

`requestCardanoCustodyDeviceKey` asks one passkey for its CIP-1854 account extended public key on a network. Every field of the answer is public: persist it to create, recover or join accounts later.

```typescript
// Hosted: the Lace signer page derives and shares the key after consent.
const signerUrl = 'https://passkey.lace.io';
const signer = createRemotePasskeySigner({ signerUrl });

button.addEventListener('click', async () => {
  signer.open(); // synchronously, inside the click
  await signer.connect();
  const deviceKey = await requestCardanoCustodyDeviceKey({
    mode: 'hosted',
    signer,
    signerUrl,
    chainId: Cardano.ChainIds.Preprod,
  });
  // { extendedAccountPublicKey, networkMagic, channel, device }
});
const deviceSigner = createRemoteCardanoCustodyDeviceSigner(signer);
```

- **Allowed sites.** The hosted signer serves custody requests only for the dApp origins its deployment lists. Any other origin gets a `RemoteSignerError` with code `custody-origin-not-allowed`, before consent. Ask the Lace team to list your origin for each signer deployment you use.
- **Local mode.** `{ mode: 'local', keySource, chainId }` takes one fresh assertion of a `createPasskeyKeySource` key source and derives the key from its words. Pair it with `createLocalCardanoCustodyDeviceSigner({ keySource, origin: location.origin })`. In local mode the app is the only consent surface: the local signer runs the hosted signer's checks before its assertion and refuses the same requests, but shows nothing.
- **Channels.** A device signer refuses a binding for the other channel or another local credential with `PasskeyWalletMismatchError`. Every signature takes a fresh assertion, and the signer checks that the key it derives is the bound key before it signs.
- **Device 0.** `deviceKey.device` is key 0, with its `keyHash` and `fingerprint` (the first and last 8 hex characters). A device joins existing accounts with it. `deriveCardanoCustodyDevice(extendedAccountPublicKey, index)` derives any other index without a secret.
- **Enrollment.** A new device exports its key 0 with `exportCardanoCustodyEnrollment(deviceKey)` and hands the JSON to a listed device. The listed device reads it with `parseCardanoCustodyEnrollment(input, { networkMagic })` and runs `add-device` with its `deviceKeyHash`. Nothing authenticates the value in transit: the user compares the fingerprint the new device's signer showed with the one on the add-device consent. The listed device then exports the account record for the new device.

### Records and agent policies

- `exportCardanoCustodyAccountRecord(wallet, { accountId })` returns the public account record v1: `{ type: 'cardano-custody-account', version: 1, networkMagic, accountValidatorHash, creatorKeyHash, stakeScriptHash, address }`. It lists no devices and never changes.
- `parseCardanoCustodyAccountRecord(input, { networkMagic })` validates a record, as JSON text or an object, without reading the chain: shape, a supported contract version, the stake script hash re-derived from the creator key hash, the address re-derived byte for byte, then the network. It also accepts the upstream `{ owner, stakeScriptHash, address }` shape on the given network. A valid record names a genuine custody address; it does not prove that the account exists or lists this device.
- `exportCardanoCustodyAgentPolicy(wallet, { accountId, slot })` returns what an agent needs for one grant: `{ type: 'cardano-custody-agent-policy', version: 2, account, grantee, grant }`. `grant` is `{ slot, generation, token, asset, perCallCap, cap, lovelacePerCallCap, lovelaceCap, expiresAt, recipients }`, with integers as decimal strings, `token` the grant token's asset id and recipients in bech32. It reads the confirmed grant UTxO, so a grant still in a submitted transaction is refused (`unknown-grant`), and so is a grant that no longer works (`dead-grant`, with `liveness` in `detail`).
- The policy is a snapshot. A spend lowers the remaining caps, and a replacement moves the grant to a new slot and token, so the slot, token and caps are for information. The agent's spend finds its grant on chain by `grantee`.
- `parseCardanoCustodyAgentPolicy(input, { networkMagic })` validates a policy and returns it with `bigint` integers, address recipients and the token as an asset id. It refuses any version but 2 (`field: 'version'`). It does not check that the grant exists or that the grantee is the agent's key.

### Creating, opening and recovering accounts

```typescript
const created = await createCardanoCustodyAccount(wallet, {
  device: deviceKey,
  deviceSigner,
  sponsor,
  name: 'Treasury',
});
if (created.isErr()) throw created.error;
const { accountId, record, device } = created.value;
// Persist record and device (the binding) in app storage. Both are public.
if (created.value.status === 'created') {
  await waitForCardanoCustodyOperation(wallet, {
    accountId,
    txId: created.value.txId,
    invalidHereafter: created.value.invalidHereafter,
  });
}
```

- **Create.** `createCardanoCustodyAccount` builds on the first creator index whose stake credential nobody registered, and skips indices someone else registered first. One request examines at most 100 indices. When the scan meets an account this passkey already created, the helper reopens it and answers `status: 'exists'` without signing, so creation is idempotent per passkey and network. The order is lease, build, sponsor witness, device consent and witness, verification, merge and submission. The account opens in the wallet with the creator key bound as this app's device.
- **Open.** `openCardanoCustodyAccount(wallet, { record, device, name })` adds the account, or replaces its device binding in place when the wallet already holds it, and returns `{ accountId, entity }`. Omit `device` to open an observer. `createCardanoCustodyAccountEntity` only builds the entity, for `wallets.addWallet` on a wallet that does not hold it yet. A joining device binds `{ extendedAccountPublicKey, index: 0, keyHash: device.keyHash, channel }` from its device key.
- **Recover.** `recoverCardanoCustodyAccounts(wallet, { device })` finds and opens every account a passkey created on the network, in every supported contract version. It scans each version with that version's own CIP-1854 account key: `device.extendedAccountPublicKey` for the current version, and `device.extendedAccountPublicKeys[a]` for a version that uses another account `a`. A version without its key is reported in `unscannedVersions`. A scan stops when 20 unregistered indices follow the last account found; indices someone else registered first do not count. Past 1,000 probes in total it fails with `CardanoCustodyIndexExhaustedError` and opens nothing. An account whose state no longer lists its creator still opens, with `currentDeviceListed` false. Accounts a passkey joined as a device reopen from their record.

### Owner operations

`executeCardanoCustodyOperation(wallet, { accountId, operation, deviceSigner, sponsor })` runs one owner operation on a live account:

```typescript
const issued = await executeCardanoCustodyOperation(wallet, {
  accountId,
  operation: {
    type: 'issue-grant',
    scope: {
      grantee: HexBlob(agentKeyHash),
      asset: CARDANO_CUSTODY_LOVELACE_ASSET,
      perCallCap: 5_000_000n,
      cap: 20_000_000n,
      lovelacePerCallCap: 0n,
      lovelaceCap: 0n,
      expiresAt: BigInt(Date.parse('2026-12-31T00:00:00Z')),
      recipients: [],
    },
  },
  deviceSigner,
  sponsor,
});
// issued.value: { txId, invalidHereafter, grantSlot }: the slot the grant took
```

| `operation.type`    | Fields          | Effect                                                                                                                                                                 |
| ------------------- | --------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `issue-grant`       | `scope`         | Issues a grant in the account's next slot, in its own grant UTxO                                                                                                       |
| `replace-grant`     | `slot`, `scope` | Revokes the grant in `slot` and issues `scope` in the next slot, in one transaction: a top-up, new limits or a new grantee                                             |
| `revoke-grant`      | `slot`          | Adds the slot of a current grant to the revoked list                                                                                                                   |
| `revoke-all-grants` | none            | Raises the grant generation, which stops every grant, and empties the revoked list                                                                                     |
| `sweep-grants`      | `slots`         | Removes 1 to 8 grants that stopped working: burns their tokens, takes their slots off the revoked list, moves their lovelace to the control output                     |
| `add-device`        | `keyHash`       | Lists a device, usually from an enrollment                                                                                                                             |
| `remove-device`     | `keyHash`       | Removes a device; refuses the last one. Grants that key holds stay in force                                                                                            |
| `owner-spend`       | `outputs`       | Pays `Cardano.TxOut` outputs from plain funds without a reference script and own reserves, each to another Shelley address on the account network with its minimum ADA |
| `delegate`          | `poolId`        | Delegates the account's stake to a pool                                                                                                                                |
| `withdraw-rewards`  | none            | Withdraws the whole reward balance into the account                                                                                                                    |

- **One grant per agent key.** Issuing a grant to a grantee that holds a current grant fails with `CardanoCustodyInvalidOperationError` (`grantee-has-grant`, with the held slot in `detail`); replace that grant to change its scope. No operation raises a grant's caps, so a top-up is a replacement. The new grant takes a new slot and token. Until the replacement confirms, the old grant can still spend within its caps.
- **Devices and grantees stay apart.** The SDK refuses a grant to a listed device and a device that holds a current grant (`state-transition`, with `detail.error.code` `grantee-is-device` or `device-is-grantee`). The hosted signer warns at consent instead of refusing either shape, because the contract accepts both. Its warning about a device holding a grant relies on the app's reported grant UTxOs.
- **Limits.** An account holds at most 16 outstanding grants, including grants that stopped working, and at most 32 revoked slots. Issuing a 17th grant fails with `grant-limit`, and revoking a 33rd slot with `revoked-list-full`; sweep first. `sweep-grants` refuses a grant that still works (`sweep-not-dead`, with its `liveness`). A grant that expired is swept with a validity start after its expiry.
- **Funding.** Every operation runs in the sponsor's collateral mode. Plain funds pay the fee first, then the account's own reserves, whose remainder returns as plain funds. An operation that pays out nothing and issues no grant takes its fee from the owner fee reserve when they cannot, keeping the control output at its minimum plus a margin for the state to grow. So a revocation, a device change or a sweep needs no deposit. Owner spends need plain funds without a reference script, or own reserves.
- **Owner fee reserve.** Creation leaves the control output with what the sponsor's 6 ADA limit leaves after the fee, the stake deposit and a 0.1 ADA margin: about 3.41 ADA on Preprod, about 1.83 ADA above the minimum. `issue-grant` and `replace-grant` top the reserve up to 2.1 ADA, from plain funds in the same transaction, so the first issue on Preprod takes about 0.27 ADA more from plain funds. The target pays two revocations on a network that attaches the scripts: the first at its fee, about 0.84 ADA, and the second at its draft before evaluation, about 0.99 ADA. On Preprod a revocation costs about 0.5 ADA. They fail with `owner-reserve-required` (with `target` and `shortfall`) or `insufficient-funds` when the funds cannot pay the grant UTxO, the top-up and the fee. Collateral-mode balancing reserves a fee bound before evaluation, so an operation needs more spendable lovelace than its final fee.
- **Refusals first.** Before any sponsor or device request, the helper refuses an observer (`observer-account`), an account that is not live (`account-not-live`), a device the state does not list (`CardanoCustodyDeviceNotListedError`), and an account with another operation running or unsettled in this wallet (`CardanoCustodyOperationInProgressError`).
- **Order.** The sponsor signs before the device, so a passkey ceremony never runs for a transaction the sponsor refuses. Both witnesses are verified over the body hash and merged at the CBOR layer before submission, which records a pending activity.
- **Consent context.** The device is told the grants the operation issues (`requestedScopes`, by default the grant an `issue-grant` or `replace-grant` issues; a replacement declares only its new grant) and is sent the account's grant UTxOs. The hosted signer refuses a transaction that issues any other grant. From the grant UTxOs its consent names the grantee of a revoked grant and warns about devices that hold grants, labelled as reported by the app.
- **Stale state.** A control or fund UTxO that left the chain before the sponsor or the node sees the transaction fails with `CardanoCustodyStaleControlError` or `CardanoCustodyFundContentionError`. Wait for the wallet to sync and run the operation again.
- **Changed reward balance.** The node refuses a transaction whose withdrawal no longer takes the whole balance of its reward account, as when rewards arrive at an epoch boundary between the build and the submission. The helper then builds, signs and submits once more, which asks the sponsor and the device again; a second such refusal fails with `CardanoCustodyRewardBalanceChangedError`. `createCardanoCustodyAccount` does the same from a new lease.
- **Logic reward balance.** While the logic's reward account holds a balance, every operation fails with `CardanoCustodyLogicRewardBalanceError` before the device is asked: an `owner-spend` because the SDK refuses a draw beside a payment out of the account, and any other operation because the fee sponsor refuses a logic run that draws anything.
- **Agent policy.** For `issue-grant` and `replace-grant`, the result carries `grantSlot`, the slot the new grant took. Once the operation settles, export the agent policy of that slot.

### Grant spends for agents

An agent opens the account as an observer from its agent policy, builds an unsigned spend, signs the body hash with its own wallet (OWS), and submits. Lace never signs a grant spend, and the hosted signer refuses one.

```typescript
const policy = parseCardanoCustodyAgentPolicy(policyJson, {
  networkMagic: Cardano.NetworkMagics.Preprod,
});
const { accountId } = await openCardanoCustodyAccount(wallet, {
  record: policy.account,
  name: 'Agent',
});
// Wait until observeCardanoCustodyAccountState reports status 'live'.

const spend = await buildCardanoCustodyGrantSpend(wallet, {
  accountId,
  grantee: policy.grantee,
  outputs: [{ address: recipient, value: { coins: 2_000_000n } }],
  sponsor,
});
if (spend.isErr()) throw spend.error;

// The agent's OWS wallet signs the 32-byte body hash with the grantee key.
const signature = await signWithAgentKey(spend.value.bodyHash);

const submitted = await submitCardanoCustodyGrantSpend(wallet, {
  accountId,
  transaction: spend.value.transaction,
  agentWitness: { vkey: agentPublicKeyHex, signature },
  sponsor,
});
```

- **Select.** The spend takes the grantee's single current, unexpired grant. Name `slot` when the grantee holds more than one (`ambiguous-grant`, with the `slots`). A grantee with no grant gets `unknown-grant`; one whose grant stopped working gets `dead-grant`, with the grant's `liveness`: `revoked`, `superseded` or `expired`.
- **Build.** `buildCardanoCustodyGrantSpend` returns `{ transaction, bodyHash, fee, invalidHereafter }`. The spend references the account's control UTxO and, on Preprod, the UTxOs that park the proxy and the logic; runs the logic with a zero withdrawal from its reward account; spends the grant UTxO and plain funds of the account (never reserves); recreates the grant UTxO with the same value and the remaining caps lowered; and returns change to the account. It mints nothing and carries no certificate. Script budgets come from the provider's evaluation. The validity bound lies within both the grant expiry and the sponsor's collateral window (`validitySeconds`, 600 seconds by default, less a margin of up to a minute). Sign and submit before `invalidHereafter`. A spend the contract would refuse is never built: scope, recipient and expiry failures come back as `CardanoCustodyGrantSpendError`. Nor is one while the logic's stake credential is not registered (`CardanoCustodyLogicNotRegisteredError`) or its reward account holds a balance, which a grant spend may not draw (`CardanoCustodyLogicRewardBalanceError`).
- **Fee bound.** The caps are written before the fee is final, and the logic counts the fee both in the transaction and in the draft the provider evaluates first, so the build balances each draft at no more than the fee its caps were lowered by. It first lowers them by the outputs and `feeBound` (`CARDANO_CUSTODY_DEFAULT_GRANT_FEE_BOUND`, 1.5 ADA, when absent) and refuses a fee above it (`fee-above-bound`) or above what the caps leave (`scope`). When the outputs, that fee and a 10,000 lovelace margin leave higher caps, it builds once more with the caps lowered by them, and keeps that build when its fee fits; otherwise the first build stands. So a spend usually costs the caps its fee plus about 10,000 lovelace.
- **Grant sizing.** The account pays the fee, so it counts against the caps. Upstream's Preprod end-to-end run measured about 0.51 ADA with one fund input and 0.78 to 0.92 ADA with twelve. On a network that attaches the scripts, twelve fund inputs cost about 1.26 ADA. For a lovelace grant, `perCallCap` and `cap` must cover each payment plus the fee. For a token grant, `lovelacePerCallCap` and `lovelaceCap` must cover the fee plus the lovelace the token outputs carry. Issuing refuses per-call caps that cannot pay the smallest spend under the default bound (`grant-scope`): the minimum ADA of one output to the cheapest allowed address plus 1.5 ADA. On Preprod that is 2,349,070 lovelace for a lovelace grant that allows any address or lists an enterprise address, and 2,469,750 when its cheapest recipient is a base address. A token grant needs at least one token per spend, and lovelace caps that cover the minimum ADA of an output with that token plus 1.5 ADA. A lovelace scope violation found after the build reports the fee it counted.
- **Funds.** A spend takes at most 12 fund inputs (`fund-input-cap`); many small deposits make spends fail. Balancing seeds the fee from a per-path execution estimate and reserves a change output before evaluation. With the current Preprod parameters, a grant spend needs about 1.81 ADA of plain funds beyond its outputs; an owner operation paid from plain funds needs about 1.67 ADA beyond its outputs and any grant or reserve top-up. Where the scripts are attached, both need about 0.34 ADA more. These figures are not measured on Preprod and vary with the transaction shape, evaluated budgets and protocol parameters.
- **Submit.** `submitCardanoCustodyGrantSpend` refuses a transaction that already carries witnesses (`transaction-witnessed`) and replaced sponsor collateral (`collateral-changed`). It accepts the agent witness only when it verifies over the body hash and its key hash is the grantee the spent grant UTxO names (`CardanoCustodyAgentWitnessError`). Then the sponsor signs for its collateral, and both witnesses are merged and submitted. Any rebuild needs a new agent signature.
- **Concurrency.** Calls are exclusive per account and grantee within one SDK instance. Spends by different grantees may run side by side, also beside an owner operation. Builds for different grantees take disjoint fund UTxOs: a build waits for the builds of other grantees begun before it, each adding at most one 120-second build timeout to the wait, and a spend built and not yet submitted holds its fund UTxOs, which spends for other grantees leave out until it is submitted or its validity ends. A new spend for the same grantee replaces the hold, and a build that fails adds no hold and leaves the grantee's earlier hold in place. Agents in other processes can still select the same funds. Every owner operation replaces the control UTxO, which stops every spend built before it, and a revocation takes effect when it confirms.
- **Stale state.** An input that left the chain since the build fails, before the sponsor signs or when the sponsor or the node refuses the transaction, with `CardanoCustodyStaleControlError` (an owner operation replaced the control UTxO), `CardanoCustodyStaleGrantError` (another spend or a sweep took the grant UTxO) or `CardanoCustodyFundContentionError` (another transaction took fund UTxOs). A reward balance the spend withdraws that changed since the build, as at an epoch boundary, fails with `CardanoCustodyRewardBalanceChangedError`. Wait for the wallet to sync, build again and have the agent sign again. A sponsor refusal of the account's logic (`CardanoCustodyLogicNotServedError`) or of the script data hash (`CardanoCustodyScriptDataHashError`) does not clear on a rebuild.

### Proof of control

A listed device proves that it controls an account by signing a site's challenge (City requirement R1.3):

```typescript
// App: sign the challenge the server issued with the bound device.
const proof = await signCardanoCustodyData(wallet, {
  accountId,
  payload: HexBlob(challengeHex),
  purpose: 'sign-in', // or 'link-account'
  deviceSigner,
});

// Server: read the devices from the chain, never from the client.
const control = readCardanoCustodyControlDevices({
  accountRecord,
  chainId: Cardano.ChainIds.Preprod,
  controlUtxo, // fetched from the chain by the server
});
if (control.isErr()) throw control.error;
const verified = await verifyCardanoCustodyDataSignature({
  signature,
  key,
  payload: challengeHex,
  address: control.value.address,
  origin: 'https://city.example',
  purpose: 'sign-in',
  devices: control.value.devices,
});
```

- **Binding.** The answer is a CIP-8 `COSE_Sign1` over the unhashed payload. Its protected header binds the custody address, the site origin and the purpose, so a signature never verifies for another account, site or purpose.
- **Origin.** The hosted signer takes the origin from the message origin the signer protocol reports, never from the payload, and its consent names the origin and the purpose. A phishing site that relays a challenge gets a signature bound to its own origin, which the issuing server refuses. The local signer binds the `origin` given to `createLocalCardanoCustodyDeviceSigner`, the app's own; without it, `signData` refuses.
- **Before the device.** `signCardanoCustodyData` refuses an observer, an account without a confirmed live state, a device the confirmed state does not list, and a device signer without `signData`. It verifies the answer as a server would. Nothing is submitted, so an operation in flight does not block it.
- **Server.** `verifyCardanoCustodyDataSignature` is pure and never rejects. The challenge, the origin, the purpose and the device list are the server's own. Issue a fresh challenge per proof. Read the control UTxO at the record's address that holds the asset with policy `accountValidatorHash` and name `stakeScriptHash`, and pass it to `readCardanoCustodyControlDevices` as `{ accountRecord, chainId, controlUtxo }`. The record's `accountValidatorHash` is the account proxy, which is also the state NFT policy; the record does not name the logic, which the control datum's first field does. `readCardanoCustodyControlDevices` refuses a logic outside `CARDANO_CUSTODY_LOGIC_HASHES` with a `CardanoCustodyRequestRefusedError` (`custody-unsupported-version`, reason `unknown-logic`), since such a logic may have admitted any device. Its other refusals are `CardanoCustodyRequestRefusedError` codes too: `custody-unsupported-version` for an unknown contract version, `custody-context-mismatch` and `custody-malformed-datum`. A verification failure is a `CardanoCustodyDataSignatureError` whose `reason` names the first failed check, such as `origin-mismatch` or `device-not-listed`.

### Observing state

`observeCardanoCustodyAccountState(wallet, accountId)` emits the account's state over the in-flight view, so a submitted operation's outputs replace the UTxOs it spends at once. It emits `undefined` while nothing is known of the account's UTxOs or of its network's protocol parameters.

- `status`: `notCreated` (no control UTxO yet), `live` (one readable control state under an accepted logic) or `invalid` (with `reason`: `multiple-control-utxos`, `missing-inline-datum`, `undecodable-state`, or `unknown-logic` with the `logic` the datum names). An `invalid` account still reports `controlUtxos` and the holdings below, but no `state` or control lovelace split, and no operation runs on it.
- `funds`: plain deposits, which agents and owner operations spend.
- `reserves`: `{ own, foreign }`, deposits under an inline datum, which only owner operations spend. `own` are in the format the contract's tools write; Lace never selects `foreign` ones.
- `grants`: the grant UTxOs, each `{ utxo, grant, token }`, in slot order, and `grantLockedLovelace`, their lovelace, held until a sweep.
- `stranded`: deposits under a datum hash, which cannot be spent. `anomalies`: UTxOs holding an account token in a shape the contract rules out.
- `withdrawableRewards`, which only a listed device withdraws. The stake deposit is not counted.
- When `live`: `state` (logic, devices, grant generation, next slot, revoked slots, outstanding grants), `controlUtxo`, `controlMinimumLovelace` (locked for the account's life), `controlHeadroomLovelace` (the owner fee reserve above it), and `currentDeviceListed`, which is absent for an observer.
- `depositAddress`: present only while the account is `live` and its state lists this app's device. Offer deposits only then: funds sent to an address that is not live may never become spendable.

The wallet's token balances count plain funds without a reference script, own reserves and rewards: never plain funds carrying a reference script, foreign reserves, the control output, grant UTxOs or stranded deposits.

`observeCardanoCustodyGrantStatuses(wallet, accountId)` emits every grant UTxO with its `status`:

- `pending`: a submitted, unsettled operation issues it.
- `live`: current, and able to pay the smallest spend.
- `exhausted`: current, but its remaining caps cannot pay the smallest spend under the default fee bound.
- `expired`: its expiry is at or before the synced chain tip's time.
- `revoked`, `superseded`: a revocation, or a revoke-all, stopped it.
- `revoking`, `sweeping`: a submitted, unsettled operation revokes it or removes it.

Each entry also carries `utxo`, `grant` and `token`. Every grant counts toward the 16 outstanding grants until a sweep removes it. An agent's spend that has not settled shows its lowered caps at once. The raw selectors are `wallet.stateObservables.cardanoContext.selectCardanoCustodyAccountState$` and `selectCardanoCustodyGrantStatuses$`.

### Waiting for an operation

`waitForCardanoCustodyOperation(wallet, { accountId, txId, invalidHereafter, timeout? })` resolves with `Ok({ txId })` once the synced UTxOs show the account after the transaction: an account token in an output of the transaction, the control UTxO of an owner operation or the grant UTxO of a grant spend, or in an output of a later transaction. It fails with `CardanoCustodyOperationExpiredError` once the validity interval has passed and the wallet has dropped the pending activity without finding the transaction. With `timeout`, it fails with a `TimeoutError` after that long.

A submission that does not answer in time fails with `CardanoCustodyOutcomeUnknownError`, which carries `accountId`, `txId`, `invalidHereafter` and any `grantSlot`. The transaction may still settle: wait for it, and do not submit the operation again. Until it settles or expires, every operation on the account fails with `CardanoCustodyOperationInProgressError`.

### Fee sponsor

`createCardanoCustodySponsorClient({ baseUrl, apiKey?, fetch? })` is a thin HTTP client for the [fee sponsor service](https://github.com/Biglup/cardano-account-custody-fee-sponsor/tree/4de7a3812af99c631870724a0633f6250ed4f23a) client API (`/v1/leases` and `/v1/collateral`) at revision `4de7a38`. It accepts only an https URL, or http to a loopback host. It sends `apiKey` only as a bearer token, never puts the key in an error, and sends no `authorization` header when `apiKey` is omitted. It validates every answer, and a refusal rejects with `CardanoCustodySponsorError` (`status`, `code`, `rule`, `detail`; `code` is `unexpected_response` for an answer the service does not document).

The service sends no CORS headers, and its client keys are bearer secrets, so the key stays out of browser code:

- **Browser app.** Point `baseUrl` at a relay on your own backend and omit `apiKey`. The relay sends the method, API path and JSON body on to the service with `authorization: Bearer <key>` as its only credential, never the browser's own authorization header or cookies, and returns the service's status and JSON body unchanged. Anyone who can call the relay spends the key's quotas, so put the relay behind your app's own authentication.
- **Server-side caller.** Pass `apiKey` and point `baseUrl` at the service.

`CardanoCustodySponsor` is the interface the custody helpers take: `lease`, `signLeased` and `releaseLease` in fee mode, which the service serves for creation alone, and `collateral` and `signCollateral` in collateral mode for every other transaction. Each witness answer is witness set CBOR that holds one vkey witness by the sponsor address's payment key and nothing else. The SDK checks the service's policy rules before it asks for a witness, releases a lease only when a request fails before the sponsor may have signed, and builds once more after a `uses_shared_collateral` refusal.

The sponsor sees and co-signs every custody transaction, and every custody transaction, revocation included, needs its collateral. The service runs on Preprod only.

### Errors

Helpers that build, sign, submit, recover, wait or verify resolve to a `Result` and never reject. The device key, entity, record, enrollment and agent policy helpers throw, device signers reject, and `createCardanoCustodySponsorClient` throws a `TypeError` for a bad URL or key. Every custody error carries a string `code`.

| Error                                     | `code`                           | When                                                                                                                                                                                                                                                              |
| ----------------------------------------- | -------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `CardanoCustodyNetworkNotReadyError`      | `custody-network-not-ready`      | No network (`missing: 'network'`) or era summaries (`'era-summaries'`) within 30 seconds                                                                                                                                                                          |
| `CardanoCustodyRecordInvalidError`        | `custody-record-invalid`         | A record fails validation; `reason` names the step                                                                                                                                                                                                                |
| `CardanoCustodyUnsupportedVersionError`   | `custody-unsupported-version`    | A record or account names a contract version the SDK does not support                                                                                                                                                                                             |
| `CardanoCustodyEnrollmentInvalidError`    | `custody-enrollment-invalid`     | An enrollment is malformed, has a wrong fingerprint or is for another network                                                                                                                                                                                     |
| `CardanoCustodyAgentPolicyInvalidError`   | `custody-agent-policy-invalid`   | An agent policy or its grant is malformed, or is not version 2; `field` names the part                                                                                                                                                                            |
| `CardanoCustodyInvalidOperationError`     | `custody-invalid-operation`      | `reason`: `observer-account`, `account-not-live`, `unknown-account`, `unknown-grant`, `dead-grant`, `grantee-has-grant`, `grant-limit`, `revoked-list-full`, `sweep-not-dead`, `grant-scope`, `network-mismatch`, `state-transition`, `invalid-output` and others |
| `CardanoCustodyDeviceNotListedError`      | `custody-device-not-listed`      | The bound device is not in the account state                                                                                                                                                                                                                      |
| `CardanoCustodyOperationInProgressError`  | `custody-operation-in-progress`  | Another operation on the account, or another spend by the grantee, runs or has not settled                                                                                                                                                                        |
| `CardanoCustodyStaleControlError`         | `custody-stale-control`          | The chain's control UTxO is not the one the transaction spends or references; sync and build again                                                                                                                                                                |
| `CardanoCustodyStaleGrantError`           | `custody-stale-grant`            | The grant UTxO a spend spends left the chain, with its `slot` when known; sync and build again                                                                                                                                                                    |
| `CardanoCustodyFundContentionError`       | `custody-fund-contention`        | Another transaction spent fund UTxOs the transaction spends, in `inputs` when named; build again                                                                                                                                                                  |
| `CardanoCustodyAlreadyRegisteredError`    | `custody-already-registered`     | Someone registered the stake credential of `creatorIndex` between the creation scan and the submission; create again from a later index                                                                                                                           |
| `CardanoCustodyIndexExhaustedError`       | `custody-index-exhausted`        | Creation or recovery reached its index bound                                                                                                                                                                                                                      |
| `CardanoCustodyLogicNotRegisteredError`   | `custody-logic-not-registered`   | The stake credential of the logic the transaction runs, whose reward account is `rewardAccount`, is not registered on the network; it is registered once per network, outside Lace                                                                                |
| `CardanoCustodyLogicRewardBalanceError`   | `custody-logic-reward-balance`   | The reward account of the account's logic holds `balance` lovelace, which every transaction that runs the logic must withdraw and this transaction cannot draw; building again does not help                                                                      |
| `CardanoCustodyLogicNotServedError`       | `custody-logic-not-served`       | The fee sponsor does not serve the logic the account runs (`known_logic`); `detail` is its explanation                                                                                                                                                            |
| `CardanoCustodyScriptDataHashError`       | `custody-script-data-hash`       | The fee sponsor hashes the script data otherwise than the body commits to (`script_data_hash`), most likely under other cost models than the wallet's provider reports                                                                                            |
| `CardanoCustodyRewardBalanceChangedError` | `custody-reward-balance-changed` | A reward balance the transaction withdraws changed before the node received it, as at an epoch boundary, twice for an owner operation or a creation, which build once more after the first; build again                                                           |
| `CardanoCustodyBuildFailedError`          | `custody-build-failed`           | Any other build failure; `reason.code` is, for example, `insufficient-funds`, `owner-reserve-required`, `collateral-fee-ceiling`, `transaction-limits` or `script-evaluation-failed`                                                                              |
| `CardanoCustodyGrantSpendError`           | `custody-grant-spend`            | `reason`: `unknown-grant`, `ambiguous-grant`, `dead-grant`, `scope`, `recipient-not-allowed`, `fee-above-bound`, `fund-input-cap`, `collateral-changed` or `transaction-witnessed`                                                                                |
| `CardanoCustodyAgentWitnessError`         | `custody-agent-witness`          | The agent witness is malformed, does not verify, or is not by the grantee                                                                                                                                                                                         |
| `CardanoCustodyWitnessError`              | `custody-witness`                | The sponsor or device answer is not exactly one valid signature by the expected key                                                                                                                                                                               |
| `CardanoCustodySponsorError`              | the service's error code         | The fee sponsor refused a request for any reason the other errors do not name                                                                                                                                                                                     |
| `CardanoCustodyRequestRefusedError`       | the signer's refusal code        | The local signer refused before its passkey assertion, such as `custody-device-not-listed`                                                                                                                                                                        |
| `RemoteSignerError`                       | the signer's refusal code        | The hosted signer refused a request, such as `custody-origin-not-allowed` or `custody-device-not-listed`                                                                                                                                                          |
| `CardanoCustodyDeviceKeyMismatchError`    | `custody-device-key-mismatch`    | The passkey derives another key than the binding names                                                                                                                                                                                                            |
| `CardanoCustodyUnsupportedSignerError`    | `custody-unsupported-signer`     | The hosted signer does not serve the custody request kind (`unsupported-request`), or the device signer has no `signData`                                                                                                                                         |
| `CardanoCustodyOutcomeUnknownError`       | `custody-outcome-unknown`        | Submission timed out; the transaction may still settle                                                                                                                                                                                                            |
| `CardanoCustodyOperationExpiredError`     | `custody-operation-expired`      | The validity interval ended without the transaction settling                                                                                                                                                                                                      |
| `CardanoCustodyDataSignatureError`        | `custody-data-signature`         | A data signature does not prove control; `reason` names the first failed check                                                                                                                                                                                    |

The signer refusal codes are listed in the [signer README](../lace-passkey-signer/README.md#cardano-custody-accounts).

### Node.js

Both entries load in Node.js 20 or later, through `import` and `require()`, so a server-side agent can build and submit grant spends:

```javascript
import { buildCardanoCustodyGrantSpend } from '@input-output-hk/lace-sdk/cardano';
```

```javascript
const sdk = require('@input-output-hk/lace-sdk/cardano');
```

### Trust boundary and residual risks

The contract, the account proxy and the logic its control datum names, is the only enforcement point that holds when the agent, the app or Lace is compromised. The SDK builders, the hosted signer and the sponsor policy refuse early. [ADR 65](../../docs/adr/65-cardano-custody-account.md) has the enforcement table (City R3.3), the table of who builds, signs and submits each transaction (R4.3), and the table of who pays and who keeps state (R5.4).

The resolved inputs, the previous control state, the grant UTxOs and the record that an app hands a device signer are not checked against the chain. The hosted signer checks that they agree with the transaction bytes. It shows from the bytes the resulting devices and grant bookkeeping, every grant the transaction issues or removes, every output, the staking, the fee and the validity, and labels every fact that rests on the app's context "Reported by the app, not verified on chain".

Residual risks:

- **Unaudited contract.** Mainnet is allowed by the SDK and the hosted signer; the application holds the lock.
- **Pre-registration.** Anyone who learns a creator key hash can register its stake credential first and block creation at that index for good. Creation and recovery skip such indices; a registration between the scan and the submission fails the creation with `CardanoCustodyAlreadyRegisteredError`. The CIP-1854 account public key reveals every creator key hash, and the creation scan reveals the credentials it probes to the chain provider. A testnet creation publishes a stake credential that is valid on every network, though Mainnet creator keys sit under another CIP-1854 account.
- **Deposits before creation.** An address that is not `live` may never become spendable. Show the deposit address only while `depositAddress` is present.
- **Revocation races.** A grantee can spend within its remaining caps until a revocation confirms.
- **Owner operations stop agent spends.** Every owner operation replaces the control UTxO that grant spends reference, so spends built before it fail and must be built again.
- **Fees against caps.** A grant spend's fee comes out of the grant's caps, and its caps must leave room for the fee bound.
- **Grant lovelace.** A grant UTxO keeps its value for its life. If the ledger's price per byte rises above what that value covers, the grant can no longer be spent: revoke it, sweep it and issue a new one.
- **Deposit fragmentation.** Many small deposits mean many fund UTxOs. A grant spend takes at most 12 fund inputs (`fund-input-cap`).
- **Owner fee reserve.** The control output's headroom comes from the sponsor at creation, and any device can spend it.
- **Script-address recipients.** Funds a grant pays to a script address follow that script's rules, and a payment to the bare account proxy can never be spent.
- **Logic reward balance.** Anyone can pay into the logic's reward account, for example by naming it as a pool's reward account. Every account transaction must then withdraw that balance and keep it at the account. While the balance is not zero, every grant spend and every owner operation that pays more than its fee out of the account fail with `CardanoCustodyLogicRewardBalanceError`, whatever the fee sponsor accepts. The other operations keep the draw at the account, but the fee sponsor refuses any draw, so they fail with the same error until the balance is gone. Once the sponsor accepts draws, those operations draw the balance into the account. A creation also needs the sponsor's creation outflow bound to count the draw, which the SDK adds to the control output.
- **Logic registration.** The logic's stake credential must be registered on the network, outside Lace, before any account transaction: `CardanoCustodyLogicNotRegisteredError`.
- **Frozen contract.** Every address derives from the pinned proxy and stake script. A change to either gives every account a new address.
- **Relying party binding.** Device keys belong to the signer hostname or credential. Add a device from another relying party before a hostname retires, or owner authority is lost.
- **Synced passkeys.** Synced copies of a passkey are one device and cannot be removed separately.
- **Enrollment.** Only the user's fingerprint comparison authenticates an enrollment.
- **Sponsor dependency.** Every custody transaction needs the sponsor's collateral, and the sponsor sees every one. The hosted sponsor serves Preprod only.
- **Sponsor refusals as text.** The sponsor names the rule it refused under, and the offending input only in a free-text detail. The SDK reads its typed sponsor and stale-input errors out of that text, so a detail in other words arrives as a plain `CardanoCustodySponsorError`.
- **Unmeasured on Preprod.** No transaction built by the SDK has landed on Preprod yet. The fee, reserve and liquidity figures here come from upstream's devnet budgets and Preprod run.

## Complete Example

A working SDK consumer is available at [`lace-sdk-consumer`](https://github.com/mkazlauskas/lace-sdk-consumer).

For a Passport account module example that runs against a local Midnight network from inside this repository, see [`apps/lace-sdk-example-passport`](../lace-sdk-example-passport/README.md).

## API Reference

### Functions

| Function                                    | Description                                                      |
| ------------------------------------------- | ---------------------------------------------------------------- |
| `createLaceWallet(props)`                   | Create a headless wallet instance with modules and config        |
| `createInMemoryWalletEntity(wallet, props)` | Create a password-protected wallet entity from a mnemonic        |
| `Mnemonic.deriveFrom(entropyHex)`           | Derive a 24-word BIP39 mnemonic from hex-encoded entropy         |
| `createTxBuilder(wallet)`                   | Create a `TransactionBuilder` from wallet state (Plutus-capable) |
| `waitForNetworkInfo(wallet)`                | Wait for Cardano network info to be available                    |
| `signCardanoTx(wallet, props)`              | Sign a Cardano transaction with an in-memory wallet              |
| `submitCardanoTx(wallet, props)`            | Submit a signed Cardano transaction to the network               |

### Types

| Type                              | Description                                                                          |
| --------------------------------- | ------------------------------------------------------------------------------------ |
| `LaceWallet`                      | Wallet instance with `dispatch`, `getState`, `stateObservables`, `actionObservables` |
| `CreateLaceWalletProps`           | Options for `createLaceWallet`: `modules`, `environment`, `config`, `featureFlags`   |
| `CreateInMemoryWalletEntityProps` | Options: `mnemonicWords`, `password` (Uint8Array), `walletName`, `order?`            |
| `AppConfig`                       | Application configuration (Blockfrost, polling intervals, explorer URLs)             |
| `FeatureFlag`                     | Feature flag entry: `{ key: FeatureFlagKey, payload?: string }`                      |
| `SignCardanoTxProps`              | Options: `serializedTx`, `password?` (Uint8Array), `accountId?`                      |
| `CardanoSignResult`               | Signing result with witness set                                                      |
| `SubmitCardanoTxProps`            | Options: `serializedTx` (HexBytes)                                                   |

### Cardano custody functions

See [Cardano custody account](#cardano-custody-account). Every name is exported from both `@input-output-hk/lace-sdk` and `@input-output-hk/lace-sdk/cardano`.

| Function                                                    | Description                                                                         |
| ----------------------------------------------------------- | ----------------------------------------------------------------------------------- |
| `requestCardanoCustodyDeviceKey(props)`                     | A passkey's CIP-1854 account key on a network, `local` or `hosted`                  |
| `deriveCardanoCustodyDevice(extendedAccountPublicKey, i)`   | The device key and key hash at index `i`, without a secret                          |
| `exportCardanoCustodyEnrollment(deviceKey)`                 | The enrollment value a new device hands to a listed one                             |
| `parseCardanoCustodyEnrollment(input, { networkMagic })`    | Validate an enrollment value (throws)                                               |
| `createLocalCardanoCustodyDeviceSigner(props)`              | Device signer for a passkey the app holds; binds `origin` in data signatures        |
| `createRemoteCardanoCustodyDeviceSigner(signer)`            | Device signer backed by the hosted signer page                                      |
| `createCardanoCustodyAccount(wallet, props)`                | Create, or reopen, this passkey's account in fee mode                               |
| `openCardanoCustodyAccount(wallet, props)`                  | Add an account from its record, or replace its device binding in place              |
| `createCardanoCustodyAccountEntity(wallet, props)`          | Build an account's wallet entity for `wallets.addWallet` (throws)                   |
| `recoverCardanoCustodyAccounts(wallet, props)`              | Find and open every account a passkey created, in every contract version            |
| `exportCardanoCustodyAccountRecord(wallet, { accountId })`  | The public account record v1                                                        |
| `parseCardanoCustodyAccountRecord(input, { networkMagic })` | Validate a record offline (throws)                                                  |
| `exportCardanoCustodyAgentPolicy(wallet, props)`            | The agent policy v2 of one confirmed, working grant                                 |
| `parseCardanoCustodyAgentPolicy(input, { networkMagic })`   | Validate an agent policy v2 (throws)                                                |
| `executeCardanoCustodyOperation(wallet, props)`             | Run an owner operation in collateral mode                                           |
| `buildCardanoCustodyGrantSpend(wallet, props)`              | Build an unsigned spend under a grantee's grant for the agent to sign               |
| `submitCardanoCustodyGrantSpend(wallet, props)`             | Verify the agent witness, add the sponsor witness and submit                        |
| `waitForCardanoCustodyOperation(wallet, props)`             | Wait until a submitted operation settles or expires                                 |
| `observeCardanoCustodyAccountState(wallet, accountId)`      | Status, the balance breakdown, state and `depositAddress`                           |
| `observeCardanoCustodyGrantStatuses(wallet, accountId)`     | Every grant UTxO with its status, such as `live`, `exhausted` or `revoked`          |
| `signCardanoCustodyData(wallet, props)`                     | Prove control: a listed device signs a challenge for an origin and purpose          |
| `verifyCardanoCustodyDataSignature(props)`                  | Pure verifier for that proof against devices read from the chain                    |
| `readCardanoCustodyControlDevices(props)`                   | The devices a control UTxO lists, for a server that verifies a proof                |
| `createCardanoCustodySponsorClient(props)`                  | HTTP client for the fee sponsor service                                             |
| `isCardanoCustodyAccountAddress(address)`                   | Whether an address has a supported account proxy payment part and script stake part |

Constants: `CARDANO_CUSTODY_ACCOUNT_VALIDATOR_HASH` (the account proxy of the version new accounts use: the payment script of their addresses and the policy id of their tokens), `CARDANO_CUSTODY_ACCOUNT_VALIDATOR_HASHES` (every supported version, oldest first), `CARDANO_CUSTODY_LOGIC_HASH` (the logic new accounts run), `CARDANO_CUSTODY_LOGIC_HASHES` (every logic the SDK accepts), `CARDANO_CUSTODY_LOVELACE_ASSET` (the asset of a lovelace grant) and `CARDANO_CUSTODY_DEFAULT_GRANT_FEE_BOUND` (a grant spend's fee bound when it names none, 1.5 ADA).

### Cardano custody types

| Type                                                           | Description                                                                                   |
| -------------------------------------------------------------- | --------------------------------------------------------------------------------------------- |
| `CardanoCustodyDeviceKey`                                      | `{ extendedAccountPublicKey, networkMagic, channel, device }`, all public                     |
| `CardanoCustodyDevice`                                         | `{ index, keyHash, publicKey, fingerprint }`                                                  |
| `CardanoCustodyDeviceBinding`                                  | `{ extendedAccountPublicKey, index, keyHash, channel }`, persisted on an owner account        |
| `CardanoCustodyDeviceChannel`                                  | `{ type: 'local', credentialId, rpId }` or `{ type: 'hosted', origin }`                       |
| `CardanoCustodyEnrollment`                                     | `{ type, version: 1, networkMagic, deviceKeyHash, fingerprint }`                              |
| `CardanoCustodyAccountRecord`                                  | Public account record v1                                                                      |
| `CardanoCustodyAgentPolicy`, `CardanoCustodyParsedAgentPolicy` | Agent policy v2 as exported (strings) and as parsed (`bigint`, addresses)                     |
| `CardanoCustodyAgentPolicyGrant`                               | The parsed grant snapshot: `slot`, `generation`, `token`, the scope fields                    |
| `CardanoCustodyOperation`                                      | The owner operation union `executeCardanoCustodyOperation` takes                              |
| `CardanoCustodyGrantScopeRequest`                              | `{ grantee, asset, perCallCap, cap, lovelacePerCallCap, lovelaceCap, expiresAt, recipients }` |
| `CardanoCustodySubmission`                                     | `{ txId, invalidHereafter, grantSlot? }`                                                      |
| `CardanoCustodyAccountCreation`                                | Creation result: `status` `created` or `exists`, `accountId`, `record`, `device`              |
| `CardanoCustodyRecovery`                                       | `{ accounts, unscannedVersions }`                                                             |
| `CardanoCustodyGrantSpend`                                     | `{ transaction, bodyHash, fee, invalidHereafter }`                                            |
| `CardanoCustodyAgentWitness`                                   | `{ vkey, signature }`: 32-byte public key and 64-byte signature, hex                          |
| `CardanoCustodyObservedAccountState`                           | `CardanoCustodyAccountState` plus `depositAddress` on a live, listed account                  |
| `CardanoCustodyGrantWithStatus`                                | `{ utxo, grant, token, status }`                                                              |
| `CardanoCustodySignedData`                                     | `{ signature, key, address, origin, keyHash }`                                                |
| `CardanoCustodySponsor`                                        | Funding interface: `lease`, `signLeased`, `releaseLease`, `collateral`, `signCollateral`      |
| `CardanoCustodyDeviceSigner`                                   | `signTransaction(request)` and optional `signData(request)`                                   |

### Value Objects

Time utilities with nominal typing (zero runtime overhead):

```typescript
import {
  Milliseconds,
  Seconds,
  Minutes,
  Hours,
  Days,
  Timestamp,
  TimeSpan,
} from '@input-output-hk/lace-sdk';
```

Other value objects: `BigNumber`, `HexBytes`, `ByteArray`, `Uri`

### Feature Flags

| Flag                        | Purpose                                               |
| --------------------------- | ----------------------------------------------------- |
| `FEATURE_FLAG_CARDANO`      | Enable Cardano blockchain support                     |
| `FEATURE_FLAG_NETWORK_TYPE` | Set default network type (`'mainnet'` or `'testnet'`) |

## License

Apache-2.0
